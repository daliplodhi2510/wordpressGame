	<meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>APPLE | THERAPEUTICS</title>
   <link href="<?php echo base_url();?>assets/admin_assets/css/bootstrap.min.css" rel="stylesheet">
   <link href="<?php echo base_url();?>assets/admin_assets/font-awesome/css/font-awesome.css" rel="stylesheet">
   <!-- Toastr style -->
   <link href="<?php echo base_url();?>assets/admin_assets/css/plugins/toastr/toastr.min.css" rel="stylesheet">
   <!-- Gritter -->
   <link href="<?php echo base_url();?>assets/admin_assets/js/plugins/gritter/jquery.gritter.css" rel="stylesheet">
   <link href="<?php echo base_url();?>assets/admin_assets/css/animate.css" rel="stylesheet">
   <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.1/summernote.css" rel="stylesheet">
   <link href="<?php echo base_url();?>assets/admin_assets/css/summernote-bs3.css" rel="stylesheet">
   <link href="<?php echo base_url();?>assets/admin_assets/css/style.css" rel="stylesheet">
   <link href="<?php echo base_url();?>assets/admin_assets/css/parsley.css" rel="stylesheet">
   
  
  