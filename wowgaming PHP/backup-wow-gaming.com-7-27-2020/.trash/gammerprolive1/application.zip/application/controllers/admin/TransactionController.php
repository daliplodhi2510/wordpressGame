<?php
	/**
	 * 
	 */
	class TransactionController extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			$this->load->model("admin/TransactionModel");
		}

		public function transactionView(){
			$data["title"]		=	"Transaction Details | Gammer Pro";
			$data["result"]		=	$this->TransactionModel->getTransactionDetails();

			$this->load->view('admin/transaction/tranaction-listing',$data);
		}
	}
?>