-- MySQL dump 10.13  Distrib 5.7.31, for Linux (x86_64)
--
-- Host: localhost    Database: shopom_gammer_pro
-- ------------------------------------------------------
-- Server version	5.7.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(150) NOT NULL,
  `pass` varchar(250) NOT NULL COMMENT 'password should be md5()',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`id`, `email`, `pass`) VALUES (1,'admin@admin.com','e10adc3949ba59abbe56e057f20f883e');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ci_admin`
--

DROP TABLE IF EXISTS `ci_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ci_admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_role_id` int(11) NOT NULL,
  `username` varchar(100) CHARACTER SET utf8 NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile_no` varchar(255) NOT NULL,
  `image` varchar(300) NOT NULL,
  `password` varchar(255) NOT NULL,
  `last_login` datetime NOT NULL,
  `is_verify` tinyint(4) NOT NULL DEFAULT '1',
  `is_admin` tinyint(4) NOT NULL DEFAULT '1',
  `is_active` tinyint(4) NOT NULL DEFAULT '0',
  `is_supper` tinyint(4) NOT NULL DEFAULT '0',
  `token` varchar(255) NOT NULL,
  `password_reset_code` varchar(255) NOT NULL,
  `last_ip` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ci_admin`
--

LOCK TABLES `ci_admin` WRITE;
/*!40000 ALTER TABLE `ci_admin` DISABLE KEYS */;
INSERT INTO `ci_admin` (`admin_id`, `admin_role_id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `image`, `password`, `last_login`, `is_verify`, `is_admin`, `is_active`, `is_supper`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (24,1,'superadmin','SuperAdmin','User','sa@g.com','324234234','ff993fc6bcf2d42a9f4e42446d8e45ea.png','$2y$10$7Oi1GNFZbgD0W5/hiqw3Auu1wAsbBHHI.VugQamXAwvd4xO51XedK','2019-01-04 11:18:36',1,1,1,1,'','','','2018-03-17 00:00:00','2019-01-26 08:01:50');
/*!40000 ALTER TABLE `ci_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ci_admin_roles`
--

DROP TABLE IF EXISTS `ci_admin_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ci_admin_roles` (
  `admin_role_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_role_title` varchar(30) CHARACTER SET utf8 NOT NULL,
  `admin_role_status` int(11) NOT NULL,
  `admin_role_created_by` int(1) NOT NULL,
  `admin_role_created_on` datetime NOT NULL,
  `admin_role_modified_by` int(11) NOT NULL,
  `admin_role_modified_on` datetime NOT NULL,
  PRIMARY KEY (`admin_role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ci_admin_roles`
--

LOCK TABLES `ci_admin_roles` WRITE;
/*!40000 ALTER TABLE `ci_admin_roles` DISABLE KEYS */;
INSERT INTO `ci_admin_roles` (`admin_role_id`, `admin_role_title`, `admin_role_status`, `admin_role_created_by`, `admin_role_created_on`, `admin_role_modified_by`, `admin_role_modified_on`) VALUES (1,'Super Admin',1,0,'2018-03-15 12:48:04',0,'2018-03-17 12:53:16'),(2,'Admin',1,0,'2018-03-15 12:53:19',0,'2019-01-26 08:27:34'),(3,'Accountant',1,0,'2018-03-15 01:46:54',0,'2019-01-26 02:17:38'),(4,'Operator',1,0,'2018-03-16 05:52:45',0,'2019-01-26 02:17:52'),(5,'customer',1,0,'2019-06-12 01:34:39',0,'0000-00-00 00:00:00'),(6,'test',1,0,'2019-06-15 03:47:34',0,'0000-00-00 00:00:00'),(7,'teste',1,0,'2019-06-17 09:43:02',0,'0000-00-00 00:00:00'),(8,'azul',1,0,'2019-06-19 03:48:22',0,'0000-00-00 00:00:00'),(9,'Tes',1,0,'2019-06-20 03:50:12',0,'0000-00-00 00:00:00'),(10,'XXXXXXXXX',0,0,'2019-06-22 09:12:01',0,'0000-00-00 00:00:00'),(11,'admin',1,0,'2019-06-23 08:00:38',0,'0000-00-00 00:00:00'),(12,'ytyt',0,0,'2019-06-25 03:30:48',0,'0000-00-00 00:00:00'),(13,'test1111',0,0,'2019-06-29 10:09:26',0,'0000-00-00 00:00:00'),(14,'test123',0,0,'2019-06-30 05:22:24',0,'0000-00-00 00:00:00'),(15,'1234',0,0,'2019-07-07 05:39:11',0,'0000-00-00 00:00:00'),(16,'mestre',0,0,'2019-07-12 03:24:29',0,'0000-00-00 00:00:00'),(17,'dthtrfgv',0,0,'2019-07-13 02:22:16',0,'0000-00-00 00:00:00'),(18,'aaaa',0,0,'2019-07-18 04:59:51',0,'0000-00-00 00:00:00'),(19,'44',0,0,'2019-07-18 04:12:25',0,'0000-00-00 00:00:00'),(20,'jkj',1,0,'2019-07-19 08:11:45',0,'0000-00-00 00:00:00'),(21,'asdasd',0,0,'2019-07-22 05:18:03',0,'0000-00-00 00:00:00'),(22,'sasassa',0,0,'2019-07-22 02:37:25',0,'0000-00-00 00:00:00'),(23,'DRIVER',0,0,'2019-07-27 01:36:33',0,'0000-00-00 00:00:00'),(24,'accuntwnt',0,0,'2019-07-31 11:37:41',0,'0000-00-00 00:00:00'),(25,'khrisna',0,0,'2019-08-01 02:02:57',0,'0000-00-00 00:00:00'),(26,'vxcvxc',1,0,'2019-08-02 02:39:52',0,'0000-00-00 00:00:00'),(27,'Supporter',1,0,'2019-08-03 11:56:40',0,'0000-00-00 00:00:00'),(28,'eee',1,0,'2019-08-06 08:22:02',0,'0000-00-00 00:00:00'),(29,'jj',1,0,'2019-08-07 08:46:58',0,'0000-00-00 00:00:00'),(30,'vbvcbvcbvcb',1,0,'2019-08-08 01:48:36',0,'0000-00-00 00:00:00'),(31,'test',1,0,'2019-08-14 04:08:16',0,'0000-00-00 00:00:00'),(32,'hvssms',1,0,'2019-08-14 02:28:14',0,'0000-00-00 00:00:00'),(33,'aa',1,0,'2019-08-17 10:56:44',0,'0000-00-00 00:00:00'),(34,'megri',1,0,'2019-08-18 02:16:40',0,'0000-00-00 00:00:00'),(35,'aaa',1,0,'2019-08-23 01:35:27',0,'0000-00-00 00:00:00'),(36,'Br',1,0,'2019-08-23 02:48:27',0,'0000-00-00 00:00:00'),(37,'Test',1,0,'2019-08-24 04:46:44',0,'0000-00-00 00:00:00'),(38,'Spieler',1,0,'2019-08-24 10:31:30',0,'0000-00-00 00:00:00'),(39,'fffgthgf',1,0,'2019-08-25 03:58:26',0,'0000-00-00 00:00:00'),(40,'Reklam',1,0,'2019-08-25 08:07:23',0,'0000-00-00 00:00:00'),(41,'shelf stacker',1,0,'2019-08-27 12:14:26',0,'0000-00-00 00:00:00'),(42,'Test',1,0,'2019-08-30 03:18:33',0,'0000-00-00 00:00:00'),(43,'abujanda',1,0,'2019-09-03 10:22:40',0,'0000-00-00 00:00:00'),(44,'Ttfdtft',1,0,'2019-09-04 07:58:16',0,'0000-00-00 00:00:00'),(45,'cutomer',1,0,'2019-09-06 12:49:48',0,'0000-00-00 00:00:00'),(46,'Slider',1,0,'2020-06-24 01:22:28',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `ci_admin_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ci_companies`
--

DROP TABLE IF EXISTS `ci_companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ci_companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ci_companies`
--

LOCK TABLES `ci_companies` WRITE;
/*!40000 ALTER TABLE `ci_companies` DISABLE KEYS */;
INSERT INTO `ci_companies` (`id`, `name`, `email`, `mobile_no`, `address1`, `address2`, `created_date`) VALUES (9,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2018-04-26 09:04:18'),(8,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2018-04-26 09:04:30'),(7,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-06-11 01:06:17'),(6,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444  United State LLC','','2017-12-11 08:12:15'),(10,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-01-27 10:01:18'),(11,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-06-12 01:06:44'),(12,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-06-15 06:06:14'),(13,'Danny Bromley','codeglamour1@gmail.com','44785566952','102 Goldview Drive','','2019-08-28 07:08:37'),(14,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-07-05 12:07:52'),(15,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-07-09 11:07:59'),(16,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-07-27 09:07:03'),(17,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-07-14 12:07:55'),(18,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','engineering hostel no 2','2019-07-16 06:07:19'),(19,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-08-31 12:08:17'),(20,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-08-09 09:08:08'),(21,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-08-15 11:08:52'),(22,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-08-17 07:08:25'),(23,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-08-19 08:08:36'),(24,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-08-25 02:08:18'),(25,'samira','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-08-26 02:08:18'),(26,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-09-01 06:09:58'),(27,'Codeglamour','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State ','','2019-09-06 12:09:46'),(28,'Codeglamourzxc','codeglamour1@gmail.com','44785566952','27 new jersey - Level 58 - CA 444 United State zczcx','','2019-09-07 02:09:00');
/*!40000 ALTER TABLE `ci_companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ci_payments`
--

DROP TABLE IF EXISTS `ci_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ci_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `invoice_no` varchar(30) NOT NULL,
  `txn_id` varchar(255) NOT NULL,
  `items_detail` longtext NOT NULL,
  `sub_total` decimal(10,2) NOT NULL,
  `total_tax` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) NOT NULL,
  `grand_total` decimal(10,2) NOT NULL,
  `currency` varchar(20) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `payment_status` varchar(30) NOT NULL,
  `client_note` longtext NOT NULL,
  `termsncondition` longtext NOT NULL,
  `due_date` date NOT NULL,
  `created_date` date NOT NULL,
  `updated_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ci_payments`
--

LOCK TABLES `ci_payments` WRITE;
/*!40000 ALTER TABLE `ci_payments` DISABLE KEYS */;
INSERT INTO `ci_payments` (`id`, `admin_id`, `user_id`, `company_id`, `invoice_no`, `txn_id`, `items_detail`, `sub_total`, `total_tax`, `discount`, `grand_total`, `currency`, `payment_method`, `payment_status`, `client_note`, `termsncondition`, `due_date`, `created_date`, `updated_date`) VALUES (4,3,34,9,'INV-2001','','a:5:{s:19:\"product_description\";a:1:{i:0;s:17:\"Samsung Galaxy S3\";}s:8:\"quantity\";a:1:{i:0;s:1:\"1\";}s:5:\"price\";a:1:{i:0;s:4:\"1000\";}s:3:\"tax\";a:1:{i:0;s:1:\"2\";}s:5:\"total\";a:1:{i:0;s:7:\"1000.00\";}}',1000.00,20.00,5.00,1015.00,'USD','','Paid','Will be delivered within next 24 hours','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2017-11-29','2017-12-06','2018-04-26'),(2,24,32,7,'INV-1001','','a:5:{s:19:\"product_description\";a:6:{i:0;s:9:\"Galaxy S6\";i:1;s:9:\"Galaxy S5\";i:2;s:3:\"234\";i:3;s:3:\"234\";i:4;s:3:\"234\";i:5;s:3:\"234\";}s:8:\"quantity\";a:6:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";}s:5:\"price\";a:6:{i:0;s:4:\"1000\";i:1;s:3:\"800\";i:2;s:0:\"\";i:3;s:0:\"\";i:4;s:0:\"\";i:5;s:0:\"\";}s:3:\"tax\";a:6:{i:0;s:1:\"5\";i:1;s:1:\"5\";i:2;s:0:\"\";i:3;s:0:\"\";i:4;s:0:\"\";i:5;s:0:\"\";}s:5:\"total\";a:6:{i:0;s:7:\"1000.00\";i:1;s:6:\"800.00\";i:2;s:4:\"0.00\";i:3;s:4:\"0.00\";i:4;s:4:\"0.00\";i:5;s:4:\"0.00\";}}',1800.00,90.00,2.00,1888.00,'USD','','Paid','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2017-12-20','2017-12-12','2019-06-11'),(3,3,33,8,'INV-2002','','a:5:{s:19:\"product_description\";a:1:{i:0;s:17:\"Samsung Galaxy S3\";}s:8:\"quantity\";a:1:{i:0;s:1:\"1\";}s:5:\"price\";a:1:{i:0;s:2:\"10\";}s:3:\"tax\";a:1:{i:0;s:1:\"2\";}s:5:\"total\";a:1:{i:0;s:5:\"10.00\";}}',10.00,0.20,1.00,9.20,'USD','','Paid','test','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2017-12-06','2017-12-06','2018-04-26'),(5,24,3,10,'10021','','a:5:{s:19:\"product_description\";a:2:{i:0;s:9:\"Galaxy S7\";i:1;s:9:\"Galaxy S8\";}s:8:\"quantity\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"3\";}s:5:\"price\";a:2:{i:0;s:3:\"300\";i:1;s:3:\"700\";}s:3:\"tax\";a:2:{i:0;s:1:\"0\";i:1;s:1:\"2\";}s:5:\"total\";a:2:{i:0;s:6:\"300.00\";i:1;s:7:\"2100.00\";}}',2400.00,42.00,1.00,2441.00,'USD','','Paid','Will be delivered on next Friday','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2018-04-20','2018-04-11','2019-01-27'),(6,24,39,11,'fdfd','','a:5:{s:19:\"product_description\";a:1:{i:0;s:5:\"dsffs\";}s:8:\"quantity\";a:1:{i:0;s:1:\"1\";}s:5:\"price\";a:1:{i:0;s:4:\"1212\";}s:3:\"tax\";a:1:{i:0;s:1:\"0\";}s:5:\"total\";a:1:{i:0;s:7:\"1212.00\";}}',1212.00,0.00,0.00,1212.00,'USD','','Unpaid','','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-06-14','2019-06-06',NULL),(7,24,33,12,'10000','','a:5:{s:19:\"product_description\";a:2:{i:0;s:4:\"Demo\";i:1;s:1:\"a\";}s:8:\"quantity\";a:2:{i:0;s:1:\"2\";i:1;s:1:\"1\";}s:5:\"price\";a:2:{i:0;s:3:\"100\";i:1;s:0:\"\";}s:3:\"tax\";a:2:{i:0;s:2:\"18\";i:1;s:0:\"\";}s:5:\"total\";a:2:{i:0;s:6:\"200.00\";i:1;s:4:\"0.00\";}}',200.00,36.00,10.00,226.00,'USD','','Paid','','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-06-25','2019-06-25','2019-06-15'),(8,24,47,13,'002','','a:5:{s:19:\"product_description\";a:1:{i:0;s:2:\"df\";}s:8:\"quantity\";a:1:{i:0;s:1:\"1\";}s:5:\"price\";a:1:{i:0;s:3:\"100\";}s:3:\"tax\";a:1:{i:0;s:2:\"18\";}s:5:\"total\";a:1:{i:0;s:6:\"100.00\";}}',100.00,18.00,0.00,118.00,'USD','','Paid','lميبنتسمنبتمينستبمسينتبمسيتمبيس','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-05-28','2019-05-28','2019-08-28'),(9,24,3,14,' ds','','a:5:{s:19:\"product_description\";a:2:{i:0;s:5:\"gngfn\";i:1;s:4:\"tdhy\";}s:8:\"quantity\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"1\";}s:5:\"price\";a:2:{i:0;s:2:\"22\";i:1;s:4:\"5868\";}s:3:\"tax\";a:2:{i:0;s:3:\"252\";i:1;s:2:\"52\";}s:5:\"total\";a:2:{i:0;s:5:\"22.00\";i:1;s:7:\"5868.00\";}}',5890.00,3106.80,50.00,8946.80,'USD','','Unpaid','sfbgnh','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-07-18','2019-07-10',NULL),(10,24,33,15,'3344fgg','','a:5:{s:19:\"product_description\";a:2:{i:0;s:5:\"dsdfs\";i:1;s:6:\"fdgdfg\";}s:8:\"quantity\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:5:\"price\";a:2:{i:0;s:3:\"500\";i:1;s:3:\"150\";}s:3:\"tax\";a:2:{i:0;s:2:\"19\";i:1;s:2:\"19\";}s:5:\"total\";a:2:{i:0;s:6:\"500.00\";i:1;s:6:\"300.00\";}}',800.00,152.00,0.00,952.00,'USD','','Paid','dsfsfd','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-07-10','2019-07-10',NULL),(11,24,45,16,'DFD','','a:5:{s:19:\"product_description\";a:1:{i:0;s:2:\"df\";}s:8:\"quantity\";a:1:{i:0;s:1:\"1\";}s:5:\"price\";a:1:{i:0;s:1:\"5\";}s:3:\"tax\";a:1:{i:0;s:1:\"5\";}s:5:\"total\";a:1:{i:0;s:4:\"5.00\";}}',5.00,0.25,0.00,5.25,'USD','','Unpaid','','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-07-30','2019-07-19','2019-07-27'),(12,25,34,17,'54543','','a:5:{s:19:\"product_description\";a:1:{i:0;s:8:\"retetret\";}s:8:\"quantity\";a:1:{i:0;s:1:\"1\";}s:5:\"price\";a:1:{i:0;s:4:\"5345\";}s:3:\"tax\";a:1:{i:0;s:6:\"534543\";}s:5:\"total\";a:1:{i:0;s:7:\"5345.00\";}}',5345.00,28571323.35,6546.00,28570122.35,'USD','','Unpaid','','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-07-12','2019-07-24',NULL),(13,24,3,18,'inv 004','','a:5:{s:19:\"product_description\";a:2:{i:0;s:6:\"chawal\";i:1;s:3:\"dal\";}s:8:\"quantity\";a:2:{i:0;s:1:\"3\";i:1;s:1:\"1\";}s:5:\"price\";a:2:{i:0;s:3:\"200\";i:1;s:2:\"50\";}s:3:\"tax\";a:2:{i:0;s:1:\"2\";i:1;s:1:\"3\";}s:5:\"total\";a:2:{i:0;s:6:\"600.00\";i:1;s:5:\"50.00\";}}',650.00,13.50,4.00,659.50,'USD','','Unpaid','sf','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-07-23','2019-07-18',NULL),(14,24,3,19,'11212','','a:5:{s:19:\"product_description\";a:1:{i:0;s:3:\"ert\";}s:8:\"quantity\";a:1:{i:0;s:1:\"1\";}s:5:\"price\";a:1:{i:0;s:7:\"1233121\";}s:3:\"tax\";a:1:{i:0;s:1:\"0\";}s:5:\"total\";a:1:{i:0;s:10:\"1233121.00\";}}',1233121.00,0.00,0.00,1233121.00,'USD','','Unpaid','','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-07-10','2019-07-02','2019-08-31'),(15,24,33,20,'wwede','','a:5:{s:19:\"product_description\";a:1:{i:0;s:7:\"ededewd\";}s:8:\"quantity\";a:1:{i:0;s:1:\"1\";}s:5:\"price\";a:1:{i:0;s:2:\"23\";}s:3:\"tax\";a:1:{i:0;s:2:\"21\";}s:5:\"total\";a:1:{i:0;s:5:\"23.00\";}}',23.00,4.83,213.00,-185.17,'USD','','Unpaid','','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullaeemco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-08-14','2019-08-09',NULL),(16,24,38,21,'56','','a:5:{s:19:\"product_description\";a:2:{i:0;s:6:\"asdsad\";i:1;s:5:\"sadas\";}s:8:\"quantity\";a:2:{i:0;s:1:\"2\";i:1;s:1:\"3\";}s:5:\"price\";a:2:{i:0;s:2:\"13\";i:1;s:2:\"44\";}s:3:\"tax\";a:2:{i:0;s:1:\"0\";i:1;s:1:\"0\";}s:5:\"total\";a:2:{i:0;s:5:\"26.00\";i:1;s:6:\"132.00\";}}',158.00,0.00,10.00,148.00,'USD','','Unpaid','','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-09-05','2019-08-28','2019-08-15'),(17,24,35,22,'dsfsf','','a:5:{s:19:\"product_description\";a:5:{i:0;s:5:\"dfdsf\";i:1;s:1:\"0\";i:2;s:1:\"0\";i:3;s:1:\"0\";i:4;s:1:\"0\";}s:8:\"quantity\";a:5:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:2:\"60\";i:4;s:1:\"1\";}s:5:\"price\";a:5:{i:0;s:2:\"50\";i:1;s:4:\"6950\";i:2;s:4:\"3200\";i:3;s:3:\"650\";i:4;s:3:\"100\";}s:3:\"tax\";a:5:{i:0;s:1:\"0\";i:1;s:1:\"0\";i:2;s:1:\"0\";i:3;s:2:\"30\";i:4;s:2:\"60\";}s:5:\"total\";a:5:{i:0;s:5:\"50.00\";i:1;s:7:\"6950.00\";i:2;s:7:\"3200.00\";i:3;s:8:\"39000.00\";i:4;s:6:\"100.00\";}}',49300.00,11760.00,600.00,60460.00,'USD','','Paid','','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-08-22','2019-08-15',NULL),(18,24,3,23,'85258','','a:5:{s:19:\"product_description\";a:10:{i:0;s:7:\"safagsg\";i:1;s:9:\"asggaasdg\";i:2;s:9:\"asdgsadhh\";i:3;s:9:\"ahhashsah\";i:4;s:7:\"ahsdhsh\";i:5;s:10:\"sdahsdhsdh\";i:6;s:8:\"sahsadhs\";i:7;s:7:\"hashsdh\";i:8;s:6:\"hsdsdh\";i:9;s:18:\"asdsdhashddhsahsad\";}s:8:\"quantity\";a:10:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";}s:5:\"price\";a:10:{i:0;s:4:\"1000\";i:1;s:4:\"1000\";i:2;s:2:\"14\";i:3;s:5:\"12515\";i:4;s:6:\"125125\";i:5;s:4:\"1515\";i:6;s:4:\"1512\";i:7;s:4:\"1252\";i:8;s:5:\"12512\";i:9;s:4:\"1525\";}s:3:\"tax\";a:10:{i:0;s:2:\"10\";i:1;s:2:\"10\";i:2;s:1:\"5\";i:3;s:1:\"5\";i:4;s:1:\"5\";i:5;s:1:\"5\";i:6;s:1:\"5\";i:7;s:1:\"5\";i:8;s:1:\"5\";i:9;s:1:\"5\";}s:5:\"total\";a:10:{i:0;s:7:\"1000.00\";i:1;s:7:\"1000.00\";i:2;s:5:\"14.00\";i:3;s:8:\"12515.00\";i:4;s:9:\"125125.00\";i:5;s:7:\"1515.00\";i:6;s:7:\"1512.00\";i:7;s:7:\"1252.00\";i:8;s:8:\"12512.00\";i:9;s:7:\"1525.00\";}}',157970.00,7998.50,4.00,165964.50,'USD','','Unpaid','','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-08-31','2019-08-06',NULL),(19,24,40,24,'12333','','a:5:{s:19:\"product_description\";a:1:{i:0;s:3:\"Yeo\";}s:8:\"quantity\";a:1:{i:0;s:1:\"1\";}s:5:\"price\";a:1:{i:0;s:5:\"20000\";}s:3:\"tax\";a:1:{i:0;s:1:\"0\";}s:5:\"total\";a:1:{i:0;s:8:\"20000.00\";}}',20000.00,0.00,0.00,20000.00,'USD','','Paid','','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-08-26','2019-08-20',NULL),(20,200,33,25,'inv-002','','a:5:{s:19:\"product_description\";a:1:{i:0;s:6:\"samira\";}s:8:\"quantity\";a:1:{i:0;s:1:\"1\";}s:5:\"price\";a:1:{i:0;s:4:\"1000\";}s:3:\"tax\";a:1:{i:0;s:2:\"50\";}s:5:\"total\";a:1:{i:0;s:7:\"1000.00\";}}',1000.00,500.00,100.00,1400.00,'USD','','Unpaid','','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-08-08','2019-07-30',NULL),(21,24,95,26,'Inv-001','','a:5:{s:19:\"product_description\";a:1:{i:0;s:14:\"Conference Fee\";}s:8:\"quantity\";a:1:{i:0;s:1:\"1\";}s:5:\"price\";a:1:{i:0;s:3:\"500\";}s:3:\"tax\";a:1:{i:0;s:2:\"10\";}s:5:\"total\";a:1:{i:0;s:6:\"500.00\";}}',500.00,50.00,0.00,550.00,'USD','','Unpaid','','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-09-10','2019-09-10',NULL),(22,24,97,27,'INV-1002','','a:5:{s:19:\"product_description\";a:1:{i:0;s:4:\"test\";}s:8:\"quantity\";a:1:{i:0;s:1:\"1\";}s:5:\"price\";a:1:{i:0;s:3:\"100\";}s:3:\"tax\";a:1:{i:0;s:2:\"12\";}s:5:\"total\";a:1:{i:0;s:6:\"100.00\";}}',100.00,12.00,0.00,112.00,'USD','','Paid','','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-09-04','2019-09-04',NULL),(23,24,44,28,'zxczxc32','','a:5:{s:19:\"product_description\";a:1:{i:0;s:5:\"saasd\";}s:8:\"quantity\";a:1:{i:0;s:1:\"1\";}s:5:\"price\";a:1:{i:0;s:5:\"32414\";}s:3:\"tax\";a:1:{i:0;s:3:\"132\";}s:5:\"total\";a:1:{i:0;s:8:\"32414.00\";}}',32414.00,42786.48,12.00,75188.48,'USD','','Paid','zxczxczxczxc','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2019-09-25','2019-09-16',NULL);
/*!40000 ALTER TABLE `ci_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ci_users`
--

DROP TABLE IF EXISTS `ci_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ci_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_no` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '1',
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  `is_verify` tinyint(4) NOT NULL DEFAULT '0',
  `is_admin` tinyint(4) NOT NULL DEFAULT '0',
  `token` varchar(255) NOT NULL,
  `password_reset_code` varchar(255) NOT NULL,
  `last_ip` varchar(30) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ci_users`
--

LOCK TABLES `ci_users` WRITE;
/*!40000 ALTER TABLE `ci_users` DISABLE KEYS */;
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (3,'admin','admin','admin','admin@admin.com','12345','$2y$10$qlAzDhBEqkKwP3OykqA7N.ZQk6T67fxD9RHfdv3zToxa9Mtwu9C/e','27 new jersey - Level 58 - CA 444 \r\nUnited State ',1,1,1,1,'','','','2017-09-29 10:09:44','2017-12-14 10:12:41'),(32,'user','user','user','user@user.com','44897866462','$2y$10$sU5msVdifYie7cZbCEnyku6hLH8Sef0VCHqO9UIOg6rsBsDtsLcyS','',1,1,1,0,'352fe25daf686bdb4edca223c921acea','','','2018-04-24 07:04:07','2019-01-26 03:01:30'),(33,'john123','john','smith','johnsmith@gmail.com','445889654656','$2y$10$CcBiQrcW597s5muOP2blhOev48gzBv2VvAVp83NsXbLo7cZM7tjGm','USA',7,1,0,0,'','','','2018-04-25 06:04:25','2019-01-24 04:01:33'),(34,'naumancs','nauman','ahmed','nacreativeprogrammer@gmail.com','4456545632215','$2y$10$Mo6FHIusHr9oDWZxJPaTC.DWZBRom7SfEryk66BbXs25OLYsmKkrK','',1,1,1,0,'','','','2018-04-25 07:04:12','2018-04-25 07:04:28'),(35,'alire','ali','raza','ali@gmail.com','12345','$2y$10$SlQ89Aezoh1k1.vLCBFiE.0XAL/.nJhojPFnolMCMayi.caAkppXW','wwe',1,1,0,0,'','','','2019-01-24 05:01:14','2019-06-11 00:00:00'),(36,'zohaib','zohaib','rana','zohaibrana@gmail.com','12345988444','$2y$10$UGpdlIob/e1gBsE2yQ/OEeqKwGGymuYFlhHogw19/SgQYRo2OqA/S','wwe',1,1,0,0,'','','','2019-01-24 05:01:01','2019-01-24 05:01:01'),(37,'d','s','s','s2333@gmail.com','9999993344','$2y$10$3UUFDhknEIIbtY6bRfd/DORe0XTcC/xTlasNZtZfoZBz2JeUOyc2a','sdfadsfasd',1,1,0,0,'','','','2019-06-11 00:00:00','2019-06-11 00:00:00'),(38,'gia','gia','gia','gia@email.com','768769809809','$2y$10$WkYB9vXJR4sc86l6pFcifejYbIQpMNaIaS5pjzERYI.djsWqCDbB6','alsdka',1,1,0,0,'','','','2019-06-11 00:00:00','2019-06-11 00:00:00'),(39,'test','test','test','test@gmail.com','9879089080','$2y$10$7xcsuPBLHv9BjKLOfDJfJ.nflJNVRCAJw4mfOWe/VJ9kct5u0EPya','gjjkjkl',1,1,0,0,'','','','2019-06-12 00:00:00','2019-06-12 00:00:00'),(40,'BlackHats','Annoymous','23','github23@gmail.com','9116587985687','$2y$10$Kaqj.MWr7ErDw79yc2/6eug5zSYYaDVbz1IMxfUQ2IfmeSl5cc2Ta','',1,0,0,0,'','','','2019-06-12 00:00:00','2019-06-12 00:00:00'),(41,'vignesh288','Vignesh','Raghavan','vickyraghav794@gmail.com','8667200540','$2y$10$ZM9kKHcXCbdYjtc2v0RscOK3BCeFaYs95u8831qD8olcFCnmI8yo6','d/288, 7th cross, dheeran nagar, trichy-9.',1,1,0,0,'','','','2019-06-12 00:00:00','2019-06-12 00:00:00'),(42,'aa','aa','aa','aa@aa.com','11112','$2y$10$12YTfm0trDnc7gbzQ92.IuO/EgTkP5kljLDX4iYHpKuBLSX4AQaEK','',1,1,0,0,'','','','2019-06-12 00:00:00','2019-08-24 00:00:00'),(43,'kaviksr','kava krishna','rao','hydkolla@gmail.com','9573846326','$2y$10$kt2rVbJKpVcKtde/So1lu.H3GfIYJ0Qb4C8tN8E3g90uVQb0mwkpi','miyapur, hyderabad',1,1,0,0,'','','','2019-06-13 00:00:00','2019-06-15 00:00:00'),(44,'drew','drew','johnson','drewjobasdf@asdf.com','9999999999999','$2y$10$nTg1D.8wwb98PqK7xjb.T.oTJYUk/r.4ZWn/BgJ7T9tgetRmN/3Qi','111111',1,1,0,0,'','','','2019-06-15 00:00:00','2019-06-15 00:00:00'),(45,'_BuTowka_','Alexey','Medvedev','butowkayt@gmail.com','8','$2y$10$yODZpktaXwxRcGWZDsRabOkL3/7UiKnyUCfJaKPHa3jvGWNH1vq6K','1',1,1,0,0,'','','','2019-06-16 00:00:00','2019-06-16 00:00:00'),(46,'sujaymondal9@gmail.com','Sujay','Mondal','sujaymondal9@gmail.com','990349510','$2y$10$pzMxNEBwetYvMzDHBKGyyeFm.yivpyVdQjhPQfXBtR26gKgZLK8Ne','Narendrapur',1,0,0,0,'','','','2019-06-17 00:00:00','2019-06-17 00:00:00'),(47,'AAAA','AAAA','BBBB','aaa@yahoo.com','123456789','$2y$10$rBWX70pEGujElAIQoOzCYeKNo1YGdEUn/UtXx9yPv1hrTJsbDi7r6','abc',1,0,0,0,'','','','2019-06-17 00:00:00','2019-06-17 00:00:00'),(48,'abc','abc','abc','xyz@yahoo.com','123456789','$2y$10$iL9yhqcaGAVVwzPKzIRfTuiVu0msUX4yyebMJJmQcq8vCXRmqxQ6.','abc',1,1,0,0,'','','','2019-06-17 00:00:00','2019-07-31 00:00:00'),(49,'teste','teste','teste','teste@teste.com','12321312','$2y$10$K0sjiisfe5o14H5sK/iPtuZRg6yn9.t3nSeiOhxsM29MpXNhoIaPa','',1,1,0,0,'','','','2019-06-17 00:00:00','2019-06-17 00:00:00'),(50,'icelandic','icelandic','icelandic','icelandic@icelandic.com','6513213564','$2y$10$y42qm1IgDwJ1YH/RdTnN4ekupririOvh3txFLMI8FjW4aRuoJnQHi','asdasd',1,0,0,0,'','','','2019-06-19 00:00:00','2019-06-19 00:00:00'),(51,'pisipc','pisipc','pisipc','pisipc@pisipc.com','902154678541','$2y$10$aYMiWGZ0zZh1UvyN.KVQguZBZQsEDF5jFlpibTQjzj2xhlVNsXt6.','sajkadhklsjdh',1,0,0,0,'','','','2019-06-19 00:00:00','2019-06-19 00:00:00'),(52,'majid','msad','asdasmd','asdasd@asad.ri','516189451','$2y$10$u1InTQvM9z39LF1u1T.kh.ql8hqDewTguXNyfVgUpIRkW2Va0TzX6','asdasd',1,0,0,0,'','','','2019-06-19 00:00:00','2019-06-19 00:00:00'),(53,'raj','bab','babba','gg@gmail.com','87878787878799','$2y$10$rbwVAMoIiZXGI8hsR6QQS.3h3KK2B0yaRu3h8zyKcPnO4aM4Fyqqe','india',1,0,0,0,'','','','2019-06-19 00:00:00','2019-06-19 00:00:00'),(54,'U001','U001','U','USER1@ADMIN.COM','875237334','$2y$10$mc.9XLtblMIXsHGlAluiEuC1FA7KewblZfoRXKrr3EinEaRuL6yJy','INDIA',1,1,0,0,'','','','2019-06-20 00:00:00','2019-06-21 00:00:00'),(55,'User','Ua','Za','uaza@admin.com','82466458214','$2y$10$LIN5I/KTkSDc0GiKFRyITOOEK0tisMaBGlg8krno4NooM/Xx5Siba','',1,1,0,0,'','','','2019-06-21 00:00:00','2019-08-30 00:00:00'),(56,'shabaka','shabaka','shabaka','asikakomfort@gmail.com','8929696633','$2y$10$zkTPiy4pj0PwFhrYJgR2Ou78fan4TrzZNJhuKavL5sd7n9KxWdmyW','Ул.Строителей 2',1,1,0,0,'','','','2019-06-23 00:00:00','2019-06-26 00:00:00'),(57,'Yuri2','Yuri','12','xinerds10@hotmail.com','12','$2y$10$Krk.28wME/1x9r15C.E/Bev.n.gudbZzOG6qq3CJXjKJWx45pR8X6','12',1,1,0,0,'','','','2019-06-27 00:00:00','2019-07-02 00:00:00'),(58,'unos','dos','tres','aaa@yahoo.com','33444444','$2y$10$5EUyRzwIwGmXj1LO5tjyAOSUcQfog1OLeAvXrSmWvgR/y3OpmVrIK','dadadad',1,1,0,0,'','','','2019-07-03 00:00:00','2019-07-05 00:00:00'),(59,'pappu','pappu','panwala','dipal1000@yahoo.com','12345780','$2y$10$czGS2Yq4x0jAw1WZZ0JYMetveRwuRe.3VmRGu2SqolBj6PaKrwqbi','abcd1234',1,1,0,0,'','','','2019-07-03 00:00:00','2019-07-03 00:00:00'),(60,'husnu','husnu','gaddar','husnu@gaddar.com','9676','$2y$10$Misc/mUPxh440omsNuzEg.sJKuQIeDPbooyYq7dPQU/rq8Ksdh7ra','jklhkjh',1,1,0,0,'','','','2019-07-08 00:00:00','2019-07-08 00:00:00'),(61,'tester','test','test','test@test.com','123456','$2y$10$jWvxdNLrqQ6MPvUMpAOY/uyL.kYH6HTQlHq9nwlfg5JIJXCqKvJrW','123',1,0,0,0,'','','','2019-07-09 00:00:00','2019-07-12 00:00:00'),(62,'jokowi','1','2','jokowi@gmail.com','0812345678','$2y$10$NzoM5wdcR/dCekHVdlQB3ODXjz1UDWhBUp2GtwrxZOafJftQEDr8i','abc',1,0,0,0,'','','','2019-07-12 00:00:00','2019-07-27 00:00:00'),(63,'Fabian Schwolow','Fabian','Schwolow','fs@die-auktionshalle-berlin.de','015168828345','$2y$10$TQAV6SUf3ODJ/4xlfjaiHur/zB8vlG4fJNtlSO3vCJillw7grlNhm','Am Stener Berg 41e',1,1,0,0,'','','','2019-07-15 00:00:00','2019-07-15 00:00:00'),(64,'12345@test.com','123','345','12345@test.com','1222333444555','$2y$10$zNpivrHakx1.AQ70j37d0.tVachdvTmjbUJ.hhIRh/yoRSqBZLOAy','Yyyyyyyyyy',1,1,0,0,'','','','2019-07-17 00:00:00','2019-07-19 00:00:00'),(65,'testando','testando','testando','testando@gmail.com','1192773882','$2y$10$9Hpi4FbNtCHrwSMxBMc/je.ZMWyaqLqciWvEtJ/VfpSahPGFg1gMO','kdsskd jdskjad',1,1,0,0,'','','','2019-07-17 00:00:00','2019-07-21 00:00:00'),(66,'vikas','kkk','kkkk','vkas@gmi.com','1111111111','$2y$10$PZVpOX7aew8uS3272kmIFe3kxcD3Wldl8IiSPZIs.cpRUV9KZPJMa','123',1,1,0,0,'','','','2019-07-20 00:00:00','2019-07-22 00:00:00'),(67,'balbeer','balbeer','nishad','nishad@gmail.com','7878787878','$2y$10$T8Wq1GK8DuR7nvs76go6q.7drwANgKQx/4YwZKzPLYazS8Ug5aF.i','jsdf',1,1,0,0,'','','','2019-07-20 00:00:00','2019-07-20 00:00:00'),(68,'mbk007','Mahesh','Kaushik','mahesh@gmail.com','9898989898','$2y$10$iyRtpGfniLBrKYdi3asUFu/k2EGInj8U2F6BeAPPJV6K.DDrdeDVC','India',1,1,0,0,'','','','2019-07-23 00:00:00','2019-07-27 00:00:00'),(69,'gov401','Krishna','Govender','krishgkrish@gmail.com','0835065108','$2y$10$LgMSTUjTcEQNRGb1bWEkpeN0U13RWGP3FvqHbRZu9FpkWLqTiUluu','9 Marula Way',1,1,0,0,'','','','2019-07-27 00:00:00','2019-07-27 00:00:00'),(70,'asas','asas','asas','admin@ynext.com','1212','$2y$10$ooeIWsfmpCQNZmos17P5zew2htfc0fmGgk3jD6kdBci4M4hMGowFC','123',1,1,0,0,'','','','2019-07-27 00:00:00','2019-07-27 00:00:00'),(71,'victortest','victortest','victortest','victortest@victortest.com','1231234567','$2y$10$3WlUjnEDxDtCk/qQTbl4ZO2LVIzv8mRHdfb1Wv2GpBuBF46w8d66G','',1,1,0,0,'','','','2019-07-29 00:00:00','2019-07-29 00:00:00'),(72,'admin1','a','a','mostafagoda199@gmail.com','23','$2y$10$4Rc912nbxVljeWMqEAaMLuaXCI5N6CI3oafc.3sGi2hQRKRN/FzYa','123123',1,0,0,0,'','','','2019-07-31 00:00:00','2019-07-31 00:00:00'),(73,'admin','a','a','mostafagoda199@gmail.com','23','$2y$10$q8WqDDa2LvEiPLjy5mm0ge9nMWGSIilMAXn8O/IteDi6OLM17I/NG','123123',1,1,0,0,'','','','2019-07-31 00:00:00','2019-08-06 00:00:00'),(74,'profihorst','rapunzel','doe','b6216160@urhen.com','012345679','$2y$10$85zegyi9wp5E3/3mwBORs.SY/hE97A6BvuwYuiyP1r8QBsTYA5bFG','',1,1,0,0,'','','','2019-08-02 00:00:00','2019-08-02 00:00:00'),(75,'sf','sdf','sdf','df@gmail.com','09079775244','$2y$10$g38c.NwBTnFJbTrv/xQHzunJwO.K8YXhi7rafsw3lB3VzwjFylBwa','Ajmer',1,1,0,0,'','','','2019-08-02 00:00:00','2019-08-02 00:00:00'),(76,'sf','sdf','sdf','df@gmail.com','09079775244','$2y$10$743G0XmpzTWtXOC7zlMTbuGZSg7Hg4kM7hgdxpJUlwBqPMAhClgcS','Ajmer',1,0,0,0,'','','','2019-08-02 00:00:00','2019-08-02 00:00:00'),(77,'efdsrg','dfg','dgdf','gdfgd@ff.com','656654656','$2y$10$JtBDIWY.9CFgbSSNbp9Lyua5k8Z47WJgn0UqAVOI00I2swVky20Yi','efdsg',1,1,0,0,'','','','2019-08-05 00:00:00','2019-08-22 00:00:00'),(78,'rj','raj','d','rj@gmail.com','2313122434','$2y$10$SgovlJ03YlRKMoB5pHMN3eXuOBbzFWvlhVdliGnIw2gy9PGPQMCiW','12345',1,1,0,0,'','','','2019-08-06 00:00:00','2019-08-17 00:00:00'),(79,'puroamor','robinson','loreto','loretoruiz@hotmail.com','54554545','$2y$10$5suuu9LzgxuNy7XDk9KmUOU.oGDN/aPiIYjT4UBW7aDAZ2rr/phau','21212',1,0,0,0,'','','','2019-08-06 00:00:00','2019-08-06 00:00:00'),(80,'ivanbasoj','Ivan lkasdjf','Baso','ivanbaso@yahoo.com','85216492550','$2y$10$KHoo5CM/NB6gKz2ejiWL/OzhMkV.8kO8WQ4CbkIBVsYQUtlB4nqnC','ivanbaso@wordpress.com',1,1,0,0,'','','','2019-08-08 00:00:00','2019-08-17 00:00:00'),(81,'teste','teste','teste','teste@teste.com','21965423263','$2y$10$8kA.UhyAAuvaU.TZS7BdXODYlZBIGqxOh2OwB9FplUaEiXhUkvpQu','teste',1,1,0,0,'','','','2019-08-08 00:00:00','2019-08-08 00:00:00'),(82,'Testing','Marco','Polo','asd@asd.aa','3333333333','$2y$10$rtm/DI8GgMIIsoEQ2hOf6ek0ZZiIfDjvSml2n5d9FldZF7IKkpwW.','',1,1,0,0,'','','','2019-08-18 00:00:00','2019-08-18 00:00:00'),(83,'test222','test','test','test@test.com','43443543543','$2y$10$/HGVtiZlI/NnBeRhrlWDYO5xr8lrDi9E9Rsv51nLnnIJy5xIBziPi','fgdgsfgdfgdgs',1,1,0,0,'','','','2019-08-18 00:00:00','2019-08-18 00:00:00'),(84,'nai','ni','ff','blckdel606@homail.com','9611245','$2y$10$ObJ8grD5S6xcF8sQdvwkAOMzdTTckI70rTR4gNIPt6CSrEHKjiA6.','1234',1,1,0,0,'','','','2019-08-19 00:00:00','2019-08-19 00:00:00'),(85,'maman','momon','memen','maman@maman.com','2','$2y$10$DOl38HyWvT354tGaoetaPeVzVjN5xIqbYMAFPlUK3ruoMcewM/UsO','maman',1,1,0,0,'','','','2019-08-19 00:00:00','2019-08-20 00:00:00'),(86,'hs777','Hussein','Saad','hs777it@gmail.com','60909090','$2y$10$RRVpoobPQLi8/DW.BSvVFed0vvNcKlsCTbrtzk21K8bwrETu8XRb6','108',1,1,0,0,'','','','2019-08-20 00:00:00','2019-08-30 00:00:00'),(87,'SnillocTV','Jack','Collins','gamer2505@gmx.de','56456465','$2y$10$J4b9pqEZzTFJdem7eHbmxeuo8Hq.HzlM23wbOKYW2gDl5SVBgP2cS','Flurstraße 48',1,1,0,0,'','','','2019-08-24 00:00:00','2019-08-25 00:00:00'),(88,'david','david','dvto','topkunlex@gmail.com','89238989398','$2y$10$gevDVndoOeR03V5UAtk.6OIOA1y0D72JNIAOGQ/prgccL.sA35gmK','Acedemy Ibadan',1,0,0,0,'','','','2019-08-25 00:00:00','2019-08-25 00:00:00'),(89,'samirayaqoub','Samira','Yaqoub','samira.yaqoub@gmail.com','05356504257','$2y$10$OHiRdn0A51OK3EncHK0hyuSLMxAL1EA9v5ai7T2e4reIfZ3uHZXwO','Istanbul',1,0,0,0,'','','','2019-08-25 00:00:00','2019-08-25 00:00:00'),(90,'hisham','hisham','hisham','samira.yaqoub@gmail.com','1234556','$2y$10$ArkDtSr77qpv4JqpKuTo8u3lOqLgGs.AgqNw3ayQfnsht6JN19N6G','ıstanbul turkey',1,0,0,0,'','','','2019-08-26 00:00:00','2019-08-27 00:00:00'),(91,'1234','1234','1234','1234@1234.com','1234','$2y$10$5iup3/ApBH1z.YCeBDSjducNIsQdIsmEXBEsmyL6S9Wo9n4i.zUsW','',1,0,0,0,'','','','2019-08-28 00:00:00','2019-08-29 00:00:00'),(92,'joao','João','Silva','joao@hotmail.com','11','$2y$10$nb.Jogd7IL02dfjjJFJDvu3aV3ierarP9Ms/dt1wSdz0ezYUW5miq','13',1,0,0,0,'','','','2019-08-29 00:00:00','2019-08-30 00:00:00'),(93,'demouser','demouser','demouser','demouser@demo.com','11234567','$2y$10$X1C4KTODK4Vqah79dcEK2.ikkyYiwI2ZZOMpX4SYrJl3OI6pi.61i','1341431 ',1,1,0,0,'','','','2019-08-30 00:00:00','2019-08-30 00:00:00'),(94,'demouser1','demouser1','demouser1','demouser1@demouser1.com','2323232323','$2y$10$a8M1.2u/KhPmiAYHUlDhi.yj6DS1JhE6cObNOk9V0FCiwRw8l9TXe','sdfvdsfvsdfq1',1,1,0,0,'','','','2019-08-30 00:00:00','2019-08-30 00:00:00'),(95,'ismailbal','Ismail','Bal','ismailbal@gmail.com','05323918776','$2y$10$yItlHr3ggKcoz5EIysRb.ucgn4P/p.YJEdOe9e6XQS8gbQNldxEY.','Deneme',1,1,0,0,'','','','2019-09-01 00:00:00','2019-09-02 00:00:00'),(96,'Raaj','R','K','ideashub.india@gmail.com','9415338665','$2y$10$zuA6h9fmcOnlQLIL/gOCPe5gdRDxyfzXkYQVdh98D1OwUMVg5pVe2','IIIrd Floor, Aditi Apptts.52 Tashkand Marg',1,1,0,0,'','','','2019-09-02 00:00:00','2019-09-06 00:00:00'),(97,'test12','test','test','test12@test.com','9177169523','$2y$10$nsZi3oN0yxRd1djekf5tK.14RugE29YlSiy0NV4k1jwIdfLnfH6s6','12345',1,1,0,0,'','','','2019-09-06 00:00:00','2019-09-06 00:00:00');
/*!40000 ALTER TABLE `ci_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_tokon`
--

DROP TABLE IF EXISTS `device_tokon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_tokon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fb_id` varchar(250) NOT NULL,
  `tokon` varchar(250) NOT NULL,
  `phone_id` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_tokon`
--

LOCK TABLES `device_tokon` WRITE;
/*!40000 ALTER TABLE `device_tokon` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_tokon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discover_section`
--

DROP TABLE IF EXISTS `discover_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discover_section` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_name` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discover_section`
--

LOCK TABLES `discover_section` WRITE;
/*!40000 ALTER TABLE `discover_section` DISABLE KEYS */;
INSERT INTO `discover_section` (`id`, `section_name`, `created`) VALUES (1,'Sport Lover','2020-05-26 02:45:28'),(2,'Smiles','2020-05-23 15:14:18'),(3,'Times We Had','2020-05-23 15:14:18'),(4,'ROCKSTAR','2020-05-23 15:14:18'),(5,'Ice Me Out','2020-05-23 15:14:18'),(6,'The Sharkboy Beat','2020-05-23 15:14:18'),(7,'Party Girl','2020-05-23 15:14:18'),(8,'Laxed (Siren Beat)','2020-05-23 15:14:18'),(9,'Dream Girl','2020-05-23 15:14:18'),(15,'true love','2020-05-27 17:03:01');
/*!40000 ALTER TABLE `discover_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fav_sound`
--

DROP TABLE IF EXISTS `fav_sound`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fav_sound` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fb_id` varchar(50) NOT NULL,
  `sound_id` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fav_sound`
--

LOCK TABLES `fav_sound` WRITE;
/*!40000 ALTER TABLE `fav_sound` DISABLE KEYS */;
/*!40000 ALTER TABLE `fav_sound` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filter_master`
--

DROP TABLE IF EXISTS `filter_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filter_master` (
  `filter_id` int(11) NOT NULL AUTO_INCREMENT,
  `filter_title` varchar(150) NOT NULL,
  `game_id` int(11) NOT NULL,
  `status` enum('0','1') NOT NULL COMMENT '0:Inactive, 1:Active',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`filter_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filter_master`
--

LOCK TABLES `filter_master` WRITE;
/*!40000 ALTER TABLE `filter_master` DISABLE KEYS */;
INSERT INTO `filter_master` (`filter_id`, `filter_title`, `game_id`, `status`, `created_date`) VALUES (1,'Killing',3,'1','2020-07-19 02:42:42'),(2,'Survival',3,'1','2020-07-19 02:42:42'),(3,'Killing',4,'1','2020-07-24 18:05:27'),(4,'Survival',4,'1','2020-07-24 18:48:57');
/*!40000 ALTER TABLE `filter_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `follow_users`
--

DROP TABLE IF EXISTS `follow_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `follow_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fb_id` varchar(250) NOT NULL,
  `followed_fb_id` varchar(250) NOT NULL COMMENT 'a person who follow by other',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `follow_users`
--

LOCK TABLES `follow_users` WRITE;
/*!40000 ALTER TABLE `follow_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `follow_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_details`
--

DROP TABLE IF EXISTS `game_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `type` enum('0','1') DEFAULT '0' COMMENT '0=game,1=banner',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_details`
--

LOCK TABLES `game_details` WRITE;
/*!40000 ALTER TABLE `game_details` DISABLE KEYS */;
INSERT INTO `game_details` (`id`, `title`, `banner`, `url`, `type`) VALUES (4,'Call Of Duty','MmZivJdXhNbaocp4qPeS.jpg','https://play.google.com/store/apps/details?id=com.activision.callofduty','0'),(3,'PUBG Mobile','tmjMbqdY3clR10EXIOai.jpg','https://play.google.com/store/apps/details?id=com.tencent.ig','0'),(5,'Free Fire','tsKRdFEQu4VcyMT6Xnib.jpg','https://play.google.com/store/apps/details?id=com.dts.freefireth','0'),(6,'Fifa 20','7gtukcQja6x9ZiL1AVzy.jpg','https://play.google.com/store/apps/details?id=com.ea.gp.fifamobile','0'),(7,'8 Ball Pool','Vfseqhm7i4u3S1v0Zkap.jpg','https://play.google.com/store/apps/details?id=com.miniclip.eightballpool','0');
/*!40000 ALTER TABLE `game_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `match_details`
--

DROP TABLE IF EXISTS `match_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `match_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game_id` int(11) NOT NULL,
  `filter_id` int(11) NOT NULL,
  `entry_type` enum('1','2') NOT NULL COMMENT '1:Trial, 2: Paid',
  `match_title` varchar(150) NOT NULL,
  `match_desc` text NOT NULL,
  `cover_image` int(11) NOT NULL,
  `platform` enum('1','2') NOT NULL DEFAULT '1' COMMENT '1:Mobile, 2:Other',
  `entry_fee` varchar(50) NOT NULL,
  `winning_price` varchar(50) NOT NULL,
  `map` varchar(100) NOT NULL,
  `match_rule` int(11) NOT NULL,
  `join_url` int(255) NOT NULL,
  `match_status` enum('0','1') NOT NULL COMMENT '0:Inactive, 1: Active',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `match_details`
--

LOCK TABLES `match_details` WRITE;
/*!40000 ALTER TABLE `match_details` DISABLE KEYS */;
INSERT INTO `match_details` (`id`, `game_id`, `filter_id`, `entry_type`, `match_title`, `match_desc`, `cover_image`, `platform`, `entry_fee`, `winning_price`, `map`, `match_rule`, `join_url`, `match_status`, `created_date`) VALUES (1,1,1,'1','match title','<p>desc</p>\r\n',3,'1','10','20','map',2,0,'1','2020-07-15 22:02:27'),(2,3,1,'1','FRee Match','<p>Prize Money 100rs</p>\r\n',4,'1','50','100','Erangel',2,0,'1','2020-07-17 08:29:23'),(3,3,2,'1','PUBG Lite new match','<p>NEW Match Prize money - 100</p>\r\n',5,'1','50','100','Erangel',2,0,'1','2020-07-17 08:32:56'),(4,1,1,'1','sddddddsa','',3,'1','10','20','MAP',2,0,'1','2020-07-18 21:35:07'),(5,4,1,'2','Call of Duty #1','<p>Prize - 20</p>\r\n',6,'1','10','20','Erangel',2,0,'1','2020-07-24 04:46:55'),(6,4,2,'2','Call of Duty #2','<p>Prize - 20</p>\r\n',7,'1','10','20','Erangel',2,0,'1','2020-07-24 04:48:58'),(7,5,1,'2','Free fire #1','<p>prize - 20</p>\r\n',10,'1','10','20','Erangel',2,0,'1','2020-07-24 05:08:50'),(8,5,1,'2','Free fire #2','<p>prize - 20</p>\r\n',11,'1','10','20','Erangel',2,0,'1','2020-07-24 05:10:11'),(9,5,1,'2','Free fire #3','<p>prize - 40</p>\r\n',12,'1','20','40','Erangel',2,0,'1','2020-07-24 05:12:02');
/*!40000 ALTER TABLE `match_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `match_with_assign_team`
--

DROP TABLE IF EXISTS `match_with_assign_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `match_with_assign_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_one_id` int(11) NOT NULL,
  `team_two_id` int(11) NOT NULL,
  `play_status` enum('1','2','3','4') NOT NULL COMMENT '1:Process,2:Playing,3:End,4:Closed',
  `winning_id` varchar(50) NOT NULL,
  `loss_id` varchar(50) NOT NULL,
  `winning_photo` varchar(255) NOT NULL,
  `loss_photo` varchar(255) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `winning_date` datetime NOT NULL,
  `loss_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `match_with_assign_team`
--

LOCK TABLES `match_with_assign_team` WRITE;
/*!40000 ALTER TABLE `match_with_assign_team` DISABLE KEYS */;
INSERT INTO `match_with_assign_team` (`id`, `team_one_id`, `team_two_id`, `play_status`, `winning_id`, `loss_id`, `winning_photo`, `loss_photo`, `created_date`, `winning_date`, `loss_date`, `updated_date`) VALUES (1,2,1,'4','8','7','winning_7_1_5f19ef8546502.jpg','','2020-07-23 14:41:16','2020-07-23 20:13:57','2020-07-23 20:13:57','2020-07-23 20:13:57'),(2,4,3,'4','7','8','winning_7_2_5f19ef94758a9.jpg','','2020-07-23 14:43:38','2020-07-23 20:14:26','2020-07-23 20:14:26','2020-07-23 20:14:26'),(3,6,5,'3','','8','','','2020-07-24 01:01:33','0000-00-00 00:00:00','2020-07-24 15:33:31','2020-07-24 15:33:31'),(4,8,7,'3','','8','','','2020-07-24 01:08:17','0000-00-00 00:00:00','2020-07-24 16:07:43','2020-07-24 16:07:43'),(5,10,9,'3','','8','','','2020-07-24 09:56:40','0000-00-00 00:00:00','2020-07-24 15:28:00','2020-07-24 15:28:00'),(6,12,11,'3','','8','','','2020-07-24 10:00:09','0000-00-00 00:00:00','2020-07-24 15:33:13','2020-07-24 15:33:13'),(7,14,13,'4','14','8','winning_14_7_5f1b18d42fddb.jpg','','2020-07-24 10:06:07','2020-07-24 17:22:28','2020-07-24 17:22:28','2020-07-24 17:22:28'),(8,18,17,'3','','7','','','2020-07-24 10:28:21','0000-00-00 00:00:00','2020-07-24 15:59:10','2020-07-24 15:59:10'),(9,20,19,'3','','8','','','2020-07-24 10:31:56','0000-00-00 00:00:00','2020-07-24 16:10:56','2020-07-24 16:10:56'),(10,21,16,'4','14','8','winning_14_10_5f1b1ee7c4f03.jpg','','2020-07-24 10:38:17','2020-07-24 17:48:23','2020-07-24 17:48:23','2020-07-24 17:48:23'),(11,23,22,'3','','8','','','2020-07-24 10:39:09','0000-00-00 00:00:00','2020-07-24 16:50:34','2020-07-24 16:50:34'),(12,25,24,'4','8','7','winning_8_12_5f1b09ae1f415.jpg','','2020-07-24 10:47:20','2020-07-24 16:51:43','2020-07-24 16:51:43','2020-07-24 16:51:43'),(13,27,26,'4','14','8','winning_14_13_5f1b195f62977.jpg','','2020-07-24 11:53:29','2020-07-24 17:24:47','2020-07-24 17:24:47','2020-07-24 17:24:47'),(14,29,28,'4','8','14','winning_8_14_5f1b19cdefd19.jpg','','2020-07-24 11:56:02','2020-07-24 17:26:37','2020-07-24 17:26:37','2020-07-24 17:26:37'),(15,33,32,'4','15','14','winning_15_15_5f1b1f628e367.jpg','','2020-07-24 12:19:38','2020-07-24 17:50:26','2020-07-24 17:50:26','2020-07-24 17:50:26'),(16,34,31,'3','','8','','','2020-07-24 12:25:20','0000-00-00 00:00:00','2020-07-24 18:57:00','2020-07-24 18:57:00');
/*!40000 ALTER TABLE `match_with_assign_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module`
--

DROP TABLE IF EXISTS `module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `module` (
  `module_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(255) NOT NULL,
  `controller_name` varchar(255) NOT NULL,
  `fa_icon` varchar(100) NOT NULL,
  `operation` text NOT NULL,
  `sort_order` tinyint(4) NOT NULL,
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module`
--

LOCK TABLES `module` WRITE;
/*!40000 ALTER TABLE `module` DISABLE KEYS */;
INSERT INTO `module` (`module_id`, `module_name`, `controller_name`, `fa_icon`, `operation`, `sort_order`) VALUES (1,'Admin List','admin','','view|add|edit|delete|change_status|access',0),(2,'Role & Permissions','admin_roles','','view|add|edit|delete|change_status|access',0),(3,'User Manage','users','','view|add|edit|delete|change_status|access',0),(4,'Invoice List','invoices','','view|add|edit|delete|access',0),(5,'CI Examples','example','','access',0),(6,'Joins','joins','','access',0),(7,'Export','export','','access',0),(8,'Slider','slider','','access',0);
/*!40000 ALTER TABLE `module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module_access`
--

DROP TABLE IF EXISTS `module_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `module_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_role_id` int(11) NOT NULL,
  `module` varchar(255) NOT NULL,
  `operation` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `RoleId` (`admin_role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=625 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module_access`
--

LOCK TABLES `module_access` WRITE;
/*!40000 ALTER TABLE `module_access` DISABLE KEYS */;
INSERT INTO `module_access` (`id`, `admin_role_id`, `module`, `operation`) VALUES (1,1,'admin','view'),(2,1,'admin','add'),(3,1,'admin','edit'),(4,1,'admin','delete'),(5,1,'admin','change_status'),(6,1,'admin','access'),(7,1,'admin_roles','view'),(8,1,'admin_roles','add'),(9,1,'admin_roles','edit'),(10,1,'admin_roles','delete'),(11,1,'admin_roles','change_status'),(12,1,'admin_roles','access'),(13,1,'users','view'),(14,1,'users','add'),(15,1,'users','edit'),(16,1,'users','delete'),(17,1,'users','change_status'),(18,1,'users','access'),(23,1,'invoices','view'),(24,1,'invoices','add'),(25,1,'invoices','edit'),(26,1,'invoices','delete'),(27,1,'invoices','access'),(28,1,'example','access'),(29,1,'joins','access'),(30,1,'export','access'),(51,3,'users','delete'),(53,3,'users','access'),(57,3,'invoices','delete'),(58,3,'invoices','edit'),(63,4,'users','add'),(64,4,'users','edit'),(65,4,'users','delete'),(66,4,'users','access'),(67,4,'users','change_status'),(69,4,'invoices','add'),(71,4,'invoices','delete'),(72,4,'invoices','access'),(88,5,'invoices','view'),(144,10,'admin','view'),(146,10,'admin_roles','view'),(148,10,'export','access'),(149,10,'joins','access'),(150,10,'example','access'),(151,10,'invoices','access'),(152,10,'invoices','view'),(153,10,'users','change_status'),(154,10,'invoices','add'),(155,10,'invoices','edit'),(156,10,'invoices','delete'),(157,10,'users','delete'),(158,10,'users','edit'),(159,10,'users','add'),(160,10,'admin_roles','access'),(161,10,'users','access'),(162,10,'admin','access'),(163,10,'admin','add'),(164,10,'admin','edit'),(165,10,'admin','delete'),(166,10,'admin_roles','delete'),(167,10,'admin_roles','add'),(168,10,'admin_roles','edit'),(169,10,'admin_roles','change_status'),(202,7,'invoices','view'),(206,4,'users','view'),(209,9,'admin_roles','change_status'),(210,9,'admin_roles','view'),(230,3,'admin_roles','access'),(233,3,'admin_roles','delete'),(234,3,'users','edit'),(235,3,'users','add'),(245,5,'example','access'),(254,17,'admin','view'),(255,17,'admin','edit'),(256,17,'admin','access'),(257,17,'admin','change_status'),(258,17,'admin','delete'),(259,17,'admin','add'),(260,17,'admin_roles','view'),(261,17,'admin_roles','access'),(262,17,'admin_roles','change_status'),(263,17,'admin_roles','add'),(264,17,'admin_roles','edit'),(265,17,'admin_roles','delete'),(266,17,'users','add'),(267,17,'users','access'),(268,17,'users','change_status'),(269,17,'users','view'),(270,17,'users','edit'),(271,17,'users','delete'),(272,17,'invoices','view'),(273,17,'invoices','access'),(274,17,'invoices','add'),(275,17,'invoices','edit'),(276,17,'invoices','delete'),(277,17,'example','access'),(278,17,'joins','access'),(279,17,'export','access'),(282,10,'admin','change_status'),(288,21,'admin','view'),(289,21,'admin','access'),(290,21,'admin','edit'),(294,10,'users','view'),(308,5,'export','access'),(331,4,'joins','access'),(345,3,'admin_roles','view'),(347,3,'admin','delete'),(348,3,'admin','add'),(349,3,'joins','access'),(350,3,'admin','view'),(351,3,'admin','change_status'),(352,27,'admin','view'),(353,27,'admin','change_status'),(354,27,'admin_roles','view'),(355,27,'admin_roles','change_status'),(356,27,'users','view'),(357,27,'users','change_status'),(358,27,'invoices','view'),(359,27,'invoices','access'),(360,27,'example','access'),(361,27,'joins','access'),(362,27,'export','access'),(363,27,'admin','add'),(364,27,'admin','access'),(365,27,'admin_roles','add'),(366,27,'admin_roles','access'),(367,27,'users','add'),(368,27,'users','access'),(369,27,'invoices','add'),(370,27,'admin','edit'),(371,27,'admin_roles','edit'),(372,27,'users','edit'),(373,27,'invoices','edit'),(374,27,'invoices','delete'),(375,27,'users','delete'),(376,27,'admin_roles','delete'),(377,27,'admin','delete'),(400,28,'users','view'),(401,28,'users','add'),(402,28,'users','edit'),(403,28,'users','delete'),(407,2,'admin_roles','add'),(408,2,'admin_roles','access'),(412,2,'users','access'),(413,2,'users','add'),(416,3,'users','change_status'),(417,3,'admin_roles','edit'),(439,5,'joins','access'),(440,2,'admin_roles','edit'),(448,7,'users','change_status'),(449,3,'admin_roles','add'),(450,3,'admin_roles','change_status'),(451,3,'users','view'),(452,4,'invoices','view'),(458,4,'example','access'),(476,25,'example','access'),(477,25,'joins','access'),(479,25,'invoices','access'),(480,25,'invoices','view'),(481,25,'users','view'),(482,25,'users','add'),(483,25,'users','access'),(484,25,'users','change_status'),(485,25,'users','edit'),(486,25,'users','delete'),(487,12,'invoices','view'),(488,6,'admin','view'),(489,6,'admin','change_status'),(493,36,'export','access'),(494,36,'invoices','delete'),(496,39,'invoices','access'),(497,39,'example','access'),(498,39,'joins','access'),(499,39,'export','access'),(500,39,'invoices','view'),(502,39,'users','view'),(503,39,'admin_roles','change_status'),(504,39,'admin_roles','view'),(505,39,'admin','change_status'),(506,39,'users','change_status'),(507,39,'invoices','add'),(508,39,'users','access'),(509,39,'users','add'),(510,39,'admin_roles','access'),(511,39,'admin_roles','add'),(512,39,'admin_roles','edit'),(513,39,'users','edit'),(514,39,'invoices','edit'),(515,39,'admin','add'),(516,39,'admin','access'),(517,39,'admin','edit'),(518,39,'admin','delete'),(519,39,'admin_roles','delete'),(520,39,'users','delete'),(521,39,'invoices','delete'),(526,40,'admin','change_status'),(527,40,'admin_roles','view'),(528,3,'admin','access'),(529,3,'admin','edit'),(530,41,'admin','delete'),(531,41,'users','delete'),(532,41,'users','add'),(537,2,'users','delete'),(539,42,'admin','view'),(540,42,'admin','change_status'),(541,42,'admin','access'),(542,42,'admin','add'),(543,42,'admin','edit'),(544,42,'admin','delete'),(545,42,'admin_roles','delete'),(546,42,'admin_roles','edit'),(547,42,'admin_roles','add'),(548,42,'admin_roles','view'),(549,42,'admin_roles','change_status'),(550,42,'users','view'),(551,42,'users','change_status'),(552,42,'users','access'),(553,42,'users','add'),(554,42,'admin_roles','access'),(555,42,'users','edit'),(556,42,'users','delete'),(557,42,'invoices','delete'),(558,42,'invoices','edit'),(559,42,'invoices','add'),(560,42,'invoices','view'),(561,42,'invoices','access'),(562,42,'example','access'),(563,42,'joins','access'),(564,42,'export','access'),(566,2,'admin','add'),(567,2,'admin','delete'),(574,2,'admin_roles','view'),(575,2,'admin_roles','change_status'),(576,3,'example','access'),(580,2,'invoices','access'),(581,2,'example','access'),(582,2,'admin','edit'),(583,3,'export','access'),(584,2,'admin','view'),(585,2,'users','view'),(586,2,'users','change_status'),(587,2,'users','edit'),(588,2,'admin_roles','delete'),(589,2,'invoices','delete'),(590,2,'invoices','edit'),(592,2,'invoices','view'),(593,2,'joins','access'),(594,2,'export','access'),(595,2,'invoices','add'),(596,2,'admin','change_status'),(597,46,'admin','view'),(598,46,'admin','add'),(599,46,'admin','edit'),(600,46,'admin','change_status'),(601,46,'admin','access'),(602,46,'admin_roles','view'),(603,46,'admin_roles','change_status'),(604,46,'admin_roles','access'),(605,46,'admin_roles','add'),(606,46,'admin_roles','edit'),(607,46,'users','add'),(608,46,'users','access'),(609,46,'users','change_status'),(610,46,'users','view'),(611,46,'users','edit'),(612,46,'invoices','edit'),(613,46,'invoices','add'),(614,46,'invoices','view'),(615,46,'invoices','access'),(616,46,'example','access'),(617,46,'joins','access'),(618,46,'export','access'),(619,46,'invoices','delete'),(620,46,'users','delete'),(621,46,'admin','delete'),(622,46,'admin_roles','delete'),(623,2,'slider','access'),(624,2,'admin','access');
/*!40000 ALTER TABLE `module_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `my_fb_id` varchar(250) NOT NULL,
  `effected_fb_id` varchar(250) NOT NULL,
  `type` varchar(250) NOT NULL COMMENT 'likes,comments,mention,followers',
  `value` varchar(250) NOT NULL COMMENT 'this could be a video id',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sound`
--

DROP TABLE IF EXISTS `sound`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sound` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sound_name` varchar(250) NOT NULL,
  `description` varchar(150) NOT NULL,
  `thum` varchar(500) NOT NULL,
  `section` varchar(250) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=154 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sound`
--

LOCK TABLES `sound` WRITE;
/*!40000 ALTER TABLE `sound` DISABLE KEYS */;
INSERT INTO `sound` (`id`, `sound_name`, `description`, `thum`, `section`, `created`) VALUES (130,'Ampinity News dont share this any one','Ampinity News dont share this any one, dont make a noice  dont make a noice ','upload/audio/1059953430.jpg','23','2020-06-25 11:48:38'),(135,'chup hai baty','indain top song','upload/audio/1059953430.jpg','26','2020-06-25 11:48:41'),(136,'chinies rock','rock music','upload/audio/1059953430.jpg','27','2020-06-25 11:48:41'),(137,'tera mukhara kia bat hai','#indian top songs','upload/audio/1059953430.jpg','26','2020-06-25 11:48:41'),(138,'vaja mai payar na jane','#sad indian songs','upload/audio/1059953430.jpg','26','2020-06-25 11:48:41'),(139,'chup han batn','snag tery panio saa #indian songs','upload/audio/1059953430.jpg','23','2020-06-25 11:48:41'),(140,'mai hu tera shahzada','top indian song','upload/audio/1059953430.jpg','22','2020-06-25 11:48:41'),(141,'indian top ads','#ad videos','upload/audio/1059953430.jpg','31','2020-06-25 11:48:41'),(142,'2020 nigah songs','black guy song','upload/audio/1059953430.jpg','27','2020-06-25 11:48:41'),(143,'light song','light song playing with music','upload/audio/1059953430.jpg','27','2020-06-25 11:48:41'),(144,'five four three two one','sexy girl singing a song','upload/audio/1059953430.jpg','27','2020-06-25 11:48:41'),(145,'sky falling down','men singing song','upload/audio/1059953430.jpg','22','2020-06-25 11:48:41'),(146,'im barby girl','barby girl','upload/audio/1059953430.jpg','29','2020-06-25 11:48:41'),(147,'low profile song','inhouse songs','upload/audio/1059953430.jpg','22','2020-06-25 11:48:41'),(148,'classic song','#classis song indian','upload/audio/1059953430.jpg','29','2020-06-25 11:48:41'),(149,'dont be aglly','aglly','upload/audio/1059953430.jpg','31','2020-06-25 11:48:41'),(150,'girls swag','#swat','upload/audio/1059953430.jpg','31','2020-06-25 11:48:41'),(151,'private school chat','trending car','upload/audio/1059953430.jpg','24','2020-06-25 11:48:41'),(152,'top rated songs','top rated songs ','upload/audio/1059953430.jpg','28','2020-06-25 11:48:41'),(153,'uae','uae 122','upload/audio/uae.jpg','28','2020-06-25 11:48:41');
/*!40000 ALTER TABLE `sound` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sound_section`
--

DROP TABLE IF EXISTS `sound_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sound_section` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_name` varchar(150) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_name` (`section_name`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sound_section`
--

LOCK TABLES `sound_section` WRITE;
/*!40000 ALTER TABLE `sound_section` DISABLE KEYS */;
INSERT INTO `sound_section` (`id`, `section_name`, `created`) VALUES (27,'Global Pop','2020-05-23 11:28:19'),(28,'Sport','2020-05-23 11:28:28'),(24,'Orignal Sounds','2020-05-23 11:27:15'),(26,'Recommended','2020-05-23 11:28:08'),(25,'Funny Sounds','2020-05-23 11:27:26'),(23,'World popolar','2020-06-16 12:02:25'),(22,'Most Popular','2020-05-21 13:19:40'),(34,'DDDDDDDDDDDDDDDDDDD','2020-06-01 08:43:15'),(29,'Electronic Music','2020-05-23 11:28:48'),(33,'Naats','2020-05-31 16:31:22'),(31,'Trending','2020-05-23 11:53:08'),(32,'TEST SECTION','2020-05-25 16:48:51');
/*!40000 ALTER TABLE `sound_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_admin_login`
--

DROP TABLE IF EXISTS `tbl_admin_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_login` (
  `admin_login_id_pk` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `phone` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `salt` varchar(64) NOT NULL,
  `create_date` varchar(64) NOT NULL,
  `modified_date` varchar(64) NOT NULL,
  `ip` varchar(64) NOT NULL,
  `status` varchar(64) NOT NULL,
  `account_type` int(11) NOT NULL DEFAULT '0' COMMENT '0 for admin 1 for deo',
  PRIMARY KEY (`admin_login_id_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_admin_login`
--

LOCK TABLES `tbl_admin_login` WRITE;
/*!40000 ALTER TABLE `tbl_admin_login` DISABLE KEYS */;
INSERT INTO `tbl_admin_login` (`admin_login_id_pk`, `name`, `phone`, `email`, `password`, `salt`, `create_date`, `modified_date`, `ip`, `status`, `account_type`) VALUES (1,'','','akanand42@gmail.com','NIzlJBo+YssDyDyhq78DkUp++YIyN2Y2MTc0YmFk','27f6174bad','2020-06-25 09:18:12','','127.0.0.1','1',0),(2,'','','superadmin@gmail.com','6wqqNMol7G/G3NpEmpsZL+9wSFA5ZjViMDc5M2Iw','9f5b0793b0','2020-06-25 10:25:38','','127.0.0.1','1',0),(3,'Anand','7982250863','akvaish47@gmail.com','WoN0Y8fjgxusCNXf77D1Yyz96lk4YjI3YTc5ZGZm','8b27a79dff','2020-07-01 10:23:54','','127.0.0.1','0',1),(4,'','','publisher@gmail.com','e666Ecge4uiHoFDAV5njZ61AP700MDM2Y2UxMjBh','4036ce120a','2020-07-03 07:35:53','','127.0.0.1','1',0);
/*!40000 ALTER TABLE `tbl_admin_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_contact`
--

DROP TABLE IF EXISTS `tbl_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_contact` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` longtext NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(70) NOT NULL,
  `address` longtext NOT NULL,
  `other` longtext NOT NULL,
  `date_created` datetime NOT NULL,
  `added_by` int(11) NOT NULL,
  `date_modify` datetime DEFAULT NULL,
  `modify_by` int(11) DEFAULT NULL,
  `whatsapp_no` varchar(20) NOT NULL,
  `messenger_id` varchar(200) NOT NULL,
  `fb_follow` varchar(200) NOT NULL,
  `ig_follow` varchar(200) NOT NULL,
  `twitter_follow` varchar(200) NOT NULL,
  `youtube_follow` varchar(200) NOT NULL,
  PRIMARY KEY (`contact_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_contact`
--

LOCK TABLES `tbl_contact` WRITE;
/*!40000 ALTER TABLE `tbl_contact` DISABLE KEYS */;
INSERT INTO `tbl_contact` (`contact_id`, `title`, `phone`, `email`, `address`, `other`, `date_created`, `added_by`, `date_modify`, `modify_by`, `whatsapp_no`, `messenger_id`, `fb_follow`, `ig_follow`, `twitter_follow`, `youtube_follow`) VALUES (1,'Mr. Kashap','7678503464','digiwizy@gmail.com','eeeeee','www.youtube.com','2019-01-08 20:01:09',9,'2020-04-24 08:04:00',6,'917678503464','1233556','http://www.facebook.com/','http://www.facebook.com/','http://www.twitter.com','http://www.youtube.comm');
/*!40000 ALTER TABLE `tbl_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_image`
--

DROP TABLE IF EXISTS `tbl_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_image` (
  `img_id` int(11) NOT NULL AUTO_INCREMENT,
  `img_type` int(11) NOT NULL DEFAULT '0' COMMENT '0=match,1=bet	',
  `image_name` varchar(250) NOT NULL,
  `image` longtext NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`img_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_image`
--

LOCK TABLES `tbl_image` WRITE;
/*!40000 ALTER TABLE `tbl_image` DISABLE KEYS */;
INSERT INTO `tbl_image` (`img_id`, `img_type`, `image_name`, `image`, `date_created`) VALUES (6,0,'call of duty 1','TWJF7VmrwSqkZN46HfLP.jpg','2020-07-24 15:35:11'),(4,0,'match','5THSYlARgCLW4n9fG7Xi.jpg','2020-07-17 19:27:21'),(5,0,'pubg 2','1m5v3LTBoMjwHI8pqPzt.jpg','2020-07-17 19:31:58'),(7,0,'call of duty 2','oitq59XvG4bPyQgY81nk.jpg','2020-07-24 15:35:30'),(8,0,'call of duty 3','49cMPjxzyBo6endsNEhX.jpg','2020-07-24 15:36:47'),(9,0,'pubg 3','qNSDf6ZtFh2aOo5y3pYe.png','2020-07-24 15:38:28'),(10,0,'Free fire 1','3tHFXaK8JLOjmiesU6Rp.jpg','2020-07-24 15:41:55'),(11,0,'Free fire 2','qgQ3NmpRSKFkn4cd1lZ9.jpg','2020-07-24 15:44:00'),(12,0,'Free fire 3','WBAVi2pHMgdc8bzRKPvY.jpg','2020-07-24 15:44:27');
/*!40000 ALTER TABLE `tbl_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_privacy_policy`
--

DROP TABLE IF EXISTS `tbl_privacy_policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_privacy_policy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext NOT NULL,
  `add_by` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  `modify_by` int(11) NOT NULL,
  `date_modify` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_privacy_policy`
--

LOCK TABLES `tbl_privacy_policy` WRITE;
/*!40000 ALTER TABLE `tbl_privacy_policy` DISABLE KEYS */;
INSERT INTO `tbl_privacy_policy` (`id`, `content`, `add_by`, `date_created`, `modify_by`, `date_modify`) VALUES (1,'<p>11PBG built the PBG app as a Free app. This SERVICE is provided by PBG&nbsp;at no cost and is intended for use as is.</p><p>This page is used to inform visitors regarding my policies with the collection, use, and disclosure of Personal Information if anyone decided to use my Service.</p><p>If you choose to use my Service, then you agree to the collection and use of information in relation to this policy. The Personal Information that I collect is used for providing and improving the Service.</p><p>I will not use or share your information with anyone except as described in this Privacy Policy.The terms used in this Privacy Policy have the same meanings as in our Terms and Conditions,</p><p>which is accessible at PBG unless otherwise defined in this Privacy Policy.</p><p><strong>Information Collection and Use</strong></p><p>For a better experience, while using our Service, I may require you to provide us with certain personally identifiable information,</p><p>including but not limited to Name,Phone,Email,Password. The information that I request will be retained on your device and is not collected by me in any way.</p><p>The app does use third party services that may collect information used to identify you.Link to privacy policy of third party service providers used by the app</p><ul><li><a data-cke-saved-href=\"https://www.google.com/policies/privacy/\" href=\"https://www.google.com/policies/privacy/\" target=\"_blank\">Google Play Services</a></li></ul><p><strong>Log Data</strong></p><p>I want to inform you that whenever you use my Service, in a case of an error in the app I collect data and information (through third party products) on your phone called Log Data.</p><p>This Log Data may include information such as your device Internet Protocol (“IP”) address, device name, operating system version, the configuration of the app when utilizing my Service,</p><p>the time and date of your use of the Service, and other statistics.</p><p><strong>Cookies</strong></p><p>Cookies are files with a small amount of data that are commonly used as anonymous unique identifiers. These are sent to your browser from the websites that you visit and are stored on your device’s internal memory.</p><p>This Service does not use these “cookies” explicitly. However, the app may use third party code and libraries that use “cookies” to collect information and improve their services. You have the option to either accept or</p><p>refuse these cookies and know when a cookie is being sent to your device. If you choose to refuse our cookies, you may not be able to use some portions of this Service.</p><p><strong>Service Providers</strong></p><p>I may employ third-party companies and individuals due to the following reasons:</p><ul><li>To facilitate our Service;</li><li>To provide the Service on our behalf;</li><li>To perform Service-related services; or</li><li>To assist us in analyzing how our Service is used.</li></ul><p>I want to inform users of this Service that these third parties have access to your Personal Information. The reason is to perform the tasks assigned to them on our behalf.</p><p>However, they are obligated not to disclose or use the information for any other purpose.</p><p><strong>Security</strong></p><p>I value your trust in providing us your Personal Information, thus we are striving to use commercially acceptable means of protecting it. But remember that no method of transmission over the internet, or method of electronic storage is 100% secure and reliable, and I cannot guarantee its absolute security.</p><p><strong>Links to Other Sites</strong></p><p>This Service may contain links to other sites. If you click on a third-party link, you will be directed to that site. Note that these external sites are not operated by me. Therefore, I strongly advise you to review the Privacy Policy of these websites. I have no control over and assume no responsibility for the content, privacy policies, or practices of any third-party sites or services.</p><p><strong>Children’s Privacy</strong></p><p>These Services do not address anyone under the age of 13. I do not knowingly collect personally identifiable information from children under 13. In the case I discover that a child under 13 has provided me with personal information,</p><p>I immediately delete this from our servers. If you are a parent or guardian and you are aware that your child has provided us with personal information, please contact me so that I will be able to do necessary actions.</p><p><strong>Changes to This Privacy Policy</strong></p><p>I may update our Privacy Policy from time to time. Thus, you are advised to review this page periodically for any changes. I will notify you of any changes by posting the new Privacy Policy on this page.</p><p>These changes are effective immediately after they are posted on this page.</p><p><strong>Contact Us</strong></p><p>If you have any questions or suggestions about my Privacy Policy, do not hesitate to contact me.</p>',0,'2020-07-08 22:40:25',0,'0000-00-00 00:00:00'),(2,'<p>11PBG built the PBG app as a Free app. This SERVICE is provided by PBG&nbsp;at no cost and is intended for use as is.</p><p>This page is used to inform visitors regarding my policies with the collection, use, and disclosure of Personal Information if anyone decided to use my Service.</p><p>If you choose to use my Service, then you agree to the collection and use of information in relation to this policy. The Personal Information that I collect is used for providing and improving the Service.</p><p>I will not use or share your information with anyone except as described in this Privacy Policy.The terms used in this Privacy Policy have the same meanings as in our Terms and Conditions,</p><p>which is accessible at PBG unless otherwise defined in this Privacy Policy.</p><p><strong>Information Collection and Use</strong></p><p>For a better experience, while using our Service, I may require you to provide us with certain personally identifiable information,</p><p>including but not limited to Name,Phone,Email,Password. The information that I request will be retained on your device and is not collected by me in any way.</p><p>The app does use third party services that may collect information used to identify you.Link to privacy policy of third party service providers used by the app</p><ul><li><a data-cke-saved-href=\"https://www.google.com/policies/privacy/\" href=\"https://www.google.com/policies/privacy/\" target=\"_blank\">Google Play Services</a></li></ul><p><strong>Log Data</strong></p><p>I want to inform you that whenever you use my Service, in a case of an error in the app I collect data and information (through third party products) on your phone called Log Data.</p><p>This Log Data may include information such as your device Internet Protocol (“IP”) address, device name, operating system version, the configuration of the app when utilizing my Service,</p><p>the time and date of your use of the Service, and other statistics.</p><p><strong>Cookies</strong></p><p>Cookies are files with a small amount of data that are commonly used as anonymous unique identifiers. These are sent to your browser from the websites that you visit and are stored on your device’s internal memory.</p><p>This Service does not use these “cookies” explicitly. However, the app may use third party code and libraries that use “cookies” to collect information and improve their services. You have the option to either accept or</p><p>refuse these cookies and know when a cookie is being sent to your device. If you choose to refuse our cookies, you may not be able to use some portions of this Service.</p><p><strong>Service Providers</strong></p><p>I may employ third-party companies and individuals due to the following reasons:</p><ul><li>To facilitate our Service;</li><li>To provide the Service on our behalf;</li><li>To perform Service-related services; or</li><li>To assist us in analyzing how our Service is used.</li></ul><p>I want to inform users of this Service that these third parties have access to your Personal Information. The reason is to perform the tasks assigned to them on our behalf.</p><p>However, they are obligated not to disclose or use the information for any other purpose.</p><p><strong>Security</strong></p><p>I value your trust in providing us your Personal Information, thus we are striving to use commercially acceptable means of protecting it. But remember that no method of transmission over the internet, or method of electronic storage is 100% secure and reliable, and I cannot guarantee its absolute security.</p><p><strong>Links to Other Sites</strong></p><p>This Service may contain links to other sites. If you click on a third-party link, you will be directed to that site. Note that these external sites are not operated by me. Therefore, I strongly advise you to review the Privacy Policy of these websites. I have no control over and assume no responsibility for the content, privacy policies, or practices of any third-party sites or services.</p><p><strong>Children’s Privacy</strong></p><p>These Services do not address anyone under the age of 13. I do not knowingly collect personally identifiable information from children under 13. In the case I discover that a child under 13 has provided me with personal information,</p><p>I immediately delete this from our servers. If you are a parent or guardian and you are aware that your child has provided us with personal information, please contact me so that I will be able to do necessary actions.</p><p><strong>Changes to This Privacy Policy</strong></p><p>I may update our Privacy Policy from time to time. Thus, you are advised to review this page periodically for any changes. I will notify you of any changes by posting the new Privacy Policy on this page.</p><p>These changes are effective immediately after they are posted on this page.</p><p><strong>Contact Us</strong></p><p>If you have any questions or suggestions about my Privacy Policy, do not hesitate to contact me.</p>',0,'2020-07-09 10:58:48',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `tbl_privacy_policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_rules`
--

DROP TABLE IF EXISTS `tbl_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_rules` (
  `rule_id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_type` int(11) NOT NULL DEFAULT '0' COMMENT '0=match,1=bet	',
  `rule_title` varchar(250) NOT NULL,
  `rules` longtext NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`rule_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_rules`
--

LOCK TABLES `tbl_rules` WRITE;
/*!40000 ALTER TABLE `tbl_rules` DISABLE KEYS */;
INSERT INTO `tbl_rules` (`rule_id`, `rule_type`, `rule_title`, `rules`, `date_created`) VALUES (2,0,'rule list','<h5><span style=\"color: rgb(255, 255, 255); font-family: &quot;exo 2&quot;; font-size: 17px;\">e.</span>Are you addicted to Online Games? Have you ever thought of earning through Online Gaming or from Playing Mobile Games? What if you were rewarded for playing your favorite games and that too of which you are addicted to? Well, Mortality Gaming is the Platform which makes this possible.</h5>','2020-07-17 19:27:00');
/*!40000 ALTER TABLE `tbl_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_terms_conditions`
--

DROP TABLE IF EXISTS `tbl_terms_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_terms_conditions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext NOT NULL,
  `add_by` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  `modify_by` int(11) NOT NULL,
  `date_modify` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_terms_conditions`
--

LOCK TABLES `tbl_terms_conditions` WRITE;
/*!40000 ALTER TABLE `tbl_terms_conditions` DISABLE KEYS */;
INSERT INTO `tbl_terms_conditions` (`id`, `content`, `add_by`, `date_created`, `modify_by`, `date_modify`) VALUES (1,'testomg amamd las',0,'2020-07-08 23:21:18',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `tbl_terms_conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_video_report`
--

DROP TABLE IF EXISTS `tbl_video_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_video_report` (
  `video_report_id_pk` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `video_id_fk` int(11) NOT NULL,
  `report_message` varchar(64) NOT NULL,
  `count_report` int(11) NOT NULL,
  `report_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_blocked` int(11) NOT NULL COMMENT 'if user 5 time report then flog 1',
  PRIMARY KEY (`video_report_id_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_video_report`
--

LOCK TABLES `tbl_video_report` WRITE;
/*!40000 ALTER TABLE `tbl_video_report` DISABLE KEYS */;
INSERT INTO `tbl_video_report` (`video_report_id_pk`, `user_id`, `video_id_fk`, `report_message`, `count_report`, `report_time`, `is_blocked`) VALUES (1,26911,10,'hello this is for testing',1,'2020-07-04 15:31:02',1),(2,26911,10,'hello this is for testing',1,'2020-07-04 15:31:02',1),(3,26911,10,'hello this is for testing',1,'2020-07-04 15:31:02',1),(4,26911,10,'hello this is for testing',1,'2020-07-04 15:31:02',1),(7,26911,10,'hello this is for testing',1,'2020-07-04 15:31:02',1),(8,26911,11,'hello this is for testing',1,'2020-07-04 15:31:45',1),(9,26911,11,'hello this is for testing',1,'2020-07-04 15:31:45',1),(10,26911,11,'hello this is for testing',1,'2020-07-04 15:31:45',1),(11,26911,11,'hello this is for testing',1,'2020-07-04 15:31:45',1),(12,26911,11,'hello this is for testing',1,'2020-07-04 15:31:45',1);
/*!40000 ALTER TABLE `tbl_video_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_player`
--

DROP TABLE IF EXISTS `team_player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_player` (
  `team_id` int(11) NOT NULL AUTO_INCREMENT,
  `game_id` int(11) NOT NULL,
  `match_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `nick_name` varchar(150) NOT NULL,
  `unique_id` varchar(150) NOT NULL,
  `winning_amount` varchar(50) NOT NULL,
  `entry_fee` varchar(50) NOT NULL,
  `assign_with_other_team` enum('0','1') NOT NULL COMMENT '0:Not Assign, 1: Assign',
  `create_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `assign_datetime` datetime NOT NULL,
  `active_status` enum('0','1') NOT NULL COMMENT '0:Not Active, 1: Active',
  PRIMARY KEY (`team_id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_player`
--

LOCK TABLES `team_player` WRITE;
/*!40000 ALTER TABLE `team_player` DISABLE KEYS */;
INSERT INTO `team_player` (`team_id`, `game_id`, `match_id`, `user_id`, `nick_name`, `unique_id`, `winning_amount`, `entry_fee`, `assign_with_other_team`, `create_datetime`, `assign_datetime`, `active_status`) VALUES (1,3,2,8,'ravisk','abcd12345','100','50','1','2020-07-23 14:41:08','2020-07-23 20:11:16','0'),(2,3,2,7,'ravisk','abcd12345','100','50','1','2020-07-23 14:41:16','2020-07-23 20:11:16','0'),(3,3,2,7,'ravisk','abcd12345','100','50','1','2020-07-23 14:43:30','2020-07-23 20:13:38','0'),(4,3,2,8,'ravisk','abcd12345','100','50','1','2020-07-23 14:43:38','2020-07-23 20:13:38','0'),(5,3,2,14,'sachin','325272836732','100','50','1','2020-07-24 01:01:28','2020-07-24 06:31:33','0'),(6,3,2,8,'raj','123456','100','50','1','2020-07-24 01:01:33','2020-07-24 06:31:33','0'),(7,3,3,14,'sachin','13152673838363748','100','50','1','2020-07-24 01:04:29','2020-07-24 06:38:17','0'),(8,3,3,8,'raj','raj','100','50','1','2020-07-24 01:08:17','2020-07-24 06:38:17','0'),(9,5,9,15,'sachin526','14266352728366383','40','20','1','2020-07-24 09:56:37','2020-07-24 15:26:40','1'),(10,5,9,8,'Raj kumar','12345678','40','20','1','2020-07-24 09:56:40','2020-07-24 15:26:40','0'),(11,4,5,8,'Raj kumar','1234567','20','10','1','2020-07-24 10:00:00','2020-07-24 15:30:09','0'),(12,4,5,15,'saxhin5262','142562727725362882','20','10','1','2020-07-24 10:00:09','2020-07-24 15:30:09','0'),(13,3,2,8,'raj kumar','12345678','100','50','1','2020-07-24 10:05:46','2020-07-24 15:36:07','0'),(14,3,2,14,'sachin5262','fshdhdhdjdjdjdbfnnf','100','50','1','2020-07-24 10:06:07','2020-07-24 15:36:07','0'),(15,4,5,8,'raj kumar','12345678','20','10','0','2020-07-24 10:08:12','0000-00-00 00:00:00','1'),(16,3,3,14,'sacgin','4252727363636','100','50','1','2020-07-24 10:10:15','2020-07-24 16:08:17','0'),(17,3,2,8,'rajkumar','12345678','100','50','1','2020-07-24 10:27:28','2020-07-24 15:58:21','0'),(18,3,2,7,'ravisk1','1244567890','100','50','1','2020-07-24 10:28:21','2020-07-24 15:58:21','0'),(19,3,2,8,'rajkumar','12345678','100','50','1','2020-07-24 10:31:45','2020-07-24 16:01:56','0'),(20,3,2,7,'ravi','0123456789','100','50','1','2020-07-24 10:31:56','2020-07-24 16:01:56','0'),(21,3,3,8,'Raj kumar','1234567','100','50','1','2020-07-24 10:38:17','2020-07-24 16:08:17','0'),(22,3,3,8,'Raj kumar','12345678','100','50','1','2020-07-24 10:39:01','2020-07-24 16:09:09','0'),(23,3,3,7,'ravis','56789','100','50','1','2020-07-24 10:39:09','2020-07-24 16:09:09','0'),(24,3,2,8,'raj kumar','12345678','100','50','1','2020-07-24 10:47:07','2020-07-24 16:17:20','0'),(25,3,2,7,'tttt','12345','100','50','1','2020-07-24 10:47:20','2020-07-24 16:17:20','0'),(26,3,2,8,'raj','1234','100','50','1','2020-07-24 11:11:42','2020-07-24 17:23:29','0'),(27,3,2,14,'sachin','163737383673838','100','50','1','2020-07-24 11:53:29','2020-07-24 17:23:29','0'),(28,5,8,14,'sachin','1363672727','20','10','1','2020-07-24 11:55:54','2020-07-24 17:26:02','0'),(29,5,8,8,'raj kumar','12345678','20','10','1','2020-07-24 11:56:02','2020-07-24 17:26:02','0'),(30,3,2,8,'raj','12345','100','50','0','2020-07-24 12:11:46','0000-00-00 00:00:00','1'),(31,3,3,14,'sachin','1324262735352727','100','50','1','2020-07-24 12:18:43','2020-07-24 17:55:20','1'),(32,5,8,15,'syed12339','5649464994','20','10','1','2020-07-24 12:19:37','2020-07-24 17:49:38','0'),(33,5,8,14,'sachin','14252525266225','20','10','1','2020-07-24 12:19:38','2020-07-24 17:49:38','0'),(34,3,3,8,'eheh','sheh','100','50','1','2020-07-24 12:25:20','2020-07-24 17:55:20','0'),(35,5,9,8,'shsu','16177','40','20','0','2020-07-24 12:43:28','0000-00-00 00:00:00','1'),(36,5,8,15,'dghsjab','294649499','20','10','0','2020-07-24 12:59:32','0000-00-00 00:00:00','1'),(37,3,3,8,'vyvyv','5678','100','50','0','2020-07-24 13:27:12','0000-00-00 00:00:00','1');
/*!40000 ALTER TABLE `team_player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_user`
--

DROP TABLE IF EXISTS `test_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_no` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_user`
--

LOCK TABLES `test_user` WRITE;
/*!40000 ALTER TABLE `test_user` DISABLE KEYS */;
INSERT INTO `test_user` (`id`, `username`, `email`, `mobile_no`) VALUES (1,'nauman','naumanahmedcs@gmail.com','3468548054'),(2,'ahmed','ahmed@gmail.com','445684332545');
/*!40000 ALTER TABLE `test_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_details`
--

DROP TABLE IF EXISTS `transaction_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `request_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `req_from` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `req_amount` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `coins_used` int(11) NOT NULL DEFAULT '0',
  `getway_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_details`
--

LOCK TABLES `transaction_details` WRITE;
/*!40000 ALTER TABLE `transaction_details` DISABLE KEYS */;
INSERT INTO `transaction_details` (`id`, `user_id`, `order_id`, `payment_id`, `request_name`, `req_from`, `req_amount`, `coins_used`, `getway_name`, `remark`, `type`, `status`, `date`) VALUES (1,'7','1587150395',NULL,NULL,NULL,'10',10,'System','Add Money to Wallet','1',1,'1587150395'),(2,'7','1587150426',NULL,NULL,NULL,'50',50,'System','Add Money to Wallet','1',1,'1587150426'),(3,'7','1587150647',NULL,NULL,NULL,'10',10,'System','Add Money to Wallet','1',1,'1587150647'),(4,'7','15871510097','15871510097',NULL,NULL,'0',0,'System','Refund Entry Fee','1',1,'1587151009'),(5,'7','15871510877','15871510877',NULL,NULL,'10',10,'System','Refund Entry Fee','1',1,'1587151087'),(6,'7','1587153344',NULL,NULL,NULL,'25',25,'System','Add Money to Wallet','1',1,'1587153344'),(7,'9','1587202099',NULL,NULL,NULL,'50',50,'System','Add Money to Wallet','1',1,'1587202099'),(8,'11','1587285123',NULL,NULL,NULL,'10',10,'System','Add Money to Wallet','1',1,'1587285123'),(9,'16','158772527016','011516748873',NULL,NULL,'10',10,'GooglePay','Added From GooglePay','1',1,'1587725270'),(10,'14','158801309714','1588013096704',NULL,NULL,'10',10,'Payumoney','null','1',1,'1588013097'),(11,'17','1588063266',NULL,NULL,NULL,'5',5,'System','Add Money to Wallet','1',0,'1588063266'),(12,'18','158807248518','1588072485342',NULL,NULL,'10',10,'Payumoney','null','1',1,'1588072485'),(13,' 17 ','1588392599 17 ',' ',NULL,NULL,' 5',5,' System',' null',' 1',1,'1588392599'),(14,'14','1588394013',NULL,NULL,NULL,'10',10,'System','Refund - Cancel Match Fee','1',1,'1588394013'),(15,'14','1588394203',NULL,NULL,NULL,'10',10,'System','Refund - Cancel Match Fee','1',1,'1588394203'),(16,'14','1588394215',NULL,NULL,NULL,'10',10,'System','Refund - Cancel Match Fee','1',1,'1588394215'),(17,'17','1588394215',NULL,NULL,NULL,'10',10,'System','Refund - Cancel Match Fee','1',1,'1588394215'),(18,'14','1588394552',NULL,NULL,NULL,'10',10,'System','Refund - Cancel Match Fee','1',1,'1588394552'),(19,'17','1588394552',NULL,NULL,NULL,'10',10,'System','Refund - Cancel Match Fee','1',1,'1588394552'),(20,'14','1588404149',NULL,NULL,NULL,'10',10,'System','Refund - Cancel Match Fee','1',1,'1588404149'),(21,'22','1588497353',NULL,NULL,NULL,'1000',1000,'System','Add Money to Wallet','1',1,'1588497353'),(22,'29','1588783820',NULL,NULL,NULL,'1000',1000,'System','Add Money to Wallet','1',1,'1588783820'),(23,'22','1588922923',NULL,NULL,NULL,'1015',1015,'System','Add Money to Wallet','1',1,'1588922923'),(24,'22','158892312922','20200508111212800110168373126094924',NULL,NULL,'25',25,'PayTm','Added From PayTm','1',1,'1588923129'),(25,'47','1591728822',NULL,NULL,NULL,'100',100,'System','Add Money to Wallet','1',1,'1591728822'),(26,'14','1591859896',NULL,NULL,NULL,'50',50,'System','Add Money to Wallet','1',1,'1591859896'),(27,'47','1591992866',NULL,NULL,NULL,'500',500,'System','Add Money to Wallet','1',1,'1591992866'),(28,'65','159199309847','159199309847',NULL,NULL,'100',100,'System','Refund Entry Fee','1',1,'1591993098'),(29,'47','1592166389',NULL,NULL,NULL,'20',20,'System','Refund - Cancel Match Fee','1',1,'1592166389'),(30,'47','159216679947',NULL,'Hemanth Reddy','100','10 50',50,'Payumoney','Redeem From Payumoney','0',0,'1592166799'),(31,'54','1592296454',NULL,NULL,NULL,'50',50,'System','Add Money to Wallet','1',1,'1592296454'),(32,'23','1592296539',NULL,NULL,'100','50',50,'System','Add Money to Wallet','1',1,'1592296539'),(33,'64','1592637537',NULL,NULL,NULL,'100',100,'System','Add Money to Wallet','1',1,'1592637537'),(34,'64','1592637790',NULL,NULL,NULL,'5000',5000,'System','Add Money to Wallet','1',1,'1592637790'),(35,'66','1592637841',NULL,NULL,NULL,'5000',5000,'System','Add Money to Wallet','1',1,'1592637841'),(36,'66','159263883266','159263883266',NULL,NULL,'1500',1500,'System','Refund Entry Fee','1',1,'1592638832'),(37,'66','159264017466','159264017466',NULL,NULL,'1500',1500,'System','Refund Entry Fee','1',1,'1592640174'),(38,'66','159264026666','159264026666',NULL,NULL,'1500',1500,'System','Refund Entry Fee','1',1,'1592640266'),(39,'66','159264032466','159264032466',NULL,NULL,'1500',1500,'System','Refund Entry Fee','1',1,'1592640324'),(40,'66','1592641799',NULL,NULL,NULL,'150',150,'System','Add Money to Wallet','1',1,'1592641799'),(41,'64','1592730727',NULL,NULL,NULL,'5000',5000,'System','Add Money to Wallet','1',1,'1592730727'),(42,'66','159280273566','159280273566',NULL,NULL,'120',120,'System','Refund Entry Fee','1',1,'1592802735'),(43,'66','159280653466','159280653466',NULL,NULL,'120',120,'System','Refund Entry Fee','1',1,'1592806534'),(44,'79','1593440930',NULL,NULL,NULL,'100',100,'System','Add Money to Wallet','1',1,'1593440930'),(45,'78','1593440937',NULL,NULL,NULL,'100',100,'System','Add Money to Wallet','1',1,'1593440937'),(46,'79','1593530821',NULL,NULL,NULL,'500',500,'System','Add Money to Wallet','1',1,'1593530821');
/*!40000 ALTER TABLE `transaction_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_details`
--

DROP TABLE IF EXISTS `user_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` text,
  `lname` text,
  `user_profile` varchar(256) DEFAULT NULL,
  `username` text,
  `password` text,
  `email` text,
  `country_code` text,
  `mobile` text,
  `gender` varchar(40) DEFAULT NULL,
  `dob` varchar(40) DEFAULT NULL,
  `user_type` text,
  `cur_balance` int(10) DEFAULT '0',
  `won_balance` int(10) DEFAULT '0',
  `bonus_balance` int(11) NOT NULL DEFAULT '0',
  `refer` text,
  `referer` text,
  `refered` int(11) DEFAULT '0',
  `device_id` varchar(255) DEFAULT NULL,
  `fcm_id` longtext NOT NULL,
  `status` text,
  `is_block` varchar(255) NOT NULL DEFAULT '0',
  `forgot_pass_identity` longtext,
  `modified_date` date DEFAULT NULL,
  `created_date` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_details`
--

LOCK TABLES `user_details` WRITE;
/*!40000 ALTER TABLE `user_details` DISABLE KEYS */;
INSERT INTO `user_details` (`id`, `fname`, `lname`, `user_profile`, `username`, `password`, `email`, `country_code`, `mobile`, `gender`, `dob`, `user_type`, `cur_balance`, `won_balance`, `bonus_balance`, `refer`, `referer`, `refered`, `device_id`, `fcm_id`, `status`, `is_block`, `forgot_pass_identity`, `modified_date`, `created_date`) VALUES (13,'Test','testing',NULL,'ravisk7','827ccb0eea8a706c4c34a16891f84e7b','test@gmail.com',NULL,'1234567890',NULL,NULL,NULL,0,0,0,NULL,NULL,0,'bjggggkhk','fcm_id','1','0',NULL,NULL,'2020-07-22'),(3,'Anand','Kashyap',NULL,'anandkashyap','e10adc3949ba59abbe56e057f20f883e','akanand@gmail.com',NULL,'7982250863',NULL,NULL,NULL,0,0,0,NULL,NULL,0,NULL,'asdfasdfsdafwerwer','1','0',NULL,NULL,'2020-07-08'),(5,'Ravi','lastname','profile_5_5f15f646990e0.jpg','username','827ccb0eea8a706c4c34a16891f84e7b','email',NULL,'12345678',NULL,NULL,NULL,0,0,0,NULL,NULL,0,NULL,'fcm_id','1','0',NULL,NULL,'2020-07-08'),(6,'Ravi','lastname',NULL,'username','827ccb0eea8a706c4c34a16891f84e7b','email',NULL,'12345678',NULL,NULL,NULL,0,0,0,NULL,NULL,0,NULL,'fcm_id','1','0',NULL,NULL,'2020-07-08'),(7,'Ravi','sk','profile_5_5f15f646990e0','ravisk','827ccb0eea8a706c4c34a16891f84e7b','ravisk@gmail.com',NULL,'123456789',NULL,NULL,NULL,0,0,0,NULL,NULL,0,NULL,'fcm_id','1','0',NULL,'2020-07-10','2020-07-08'),(8,'Raj','Kumar','profile_8_5f1b0bb62df34.jpg','raj@1991','ee47fd6550aefcaec514ad4837c242ab','rdeep24102008@gmail.com',NULL,'8749941427',NULL,NULL,NULL,0,0,0,NULL,NULL,0,NULL,'','1','0',NULL,'2020-07-20','2020-07-09'),(9,'syed','Shoaib',NULL,'syedsyd12339','1691e2c847c3c64dd9d67c3b9d6d4378','syed12339@yahoo.com',NULL,'7676681110',NULL,NULL,NULL,0,0,0,NULL,NULL,0,NULL,'','1','0',NULL,NULL,'2020-07-11'),(10,'Deepak','Jain',NULL,'121212122','e807f1fcf82d132f9bb018ca6738a19f','deepak.jain186@gmail.com',NULL,'9699457461',NULL,NULL,NULL,0,0,0,NULL,NULL,0,NULL,'','1','0',NULL,NULL,'2020-07-13'),(11,'ahsan','dawood',NULL,'ahsandawood','0192023a7bbd73250516f069df18b500','ahsandawood93@gmail.com',NULL,'3345363084',NULL,NULL,NULL,0,0,0,NULL,NULL,0,NULL,'','1','0',NULL,NULL,'2020-07-13'),(12,'ro','rock',NULL,'robo','6eea9b7ef19179a06954edd0f6c05ceb','YashMishra547@gmail.com',NULL,'9604013399',NULL,NULL,NULL,0,0,0,NULL,NULL,0,NULL,'','1','0',NULL,NULL,'2020-07-14'),(14,'sachin','kumar','profile_14_5f1aad849a8e0.jpg','diabazaar@gmail.com','25d55ad283aa400af464c76d713c07ad','diabazaar@gmail.com',NULL,'7678503464',NULL,NULL,NULL,0,0,0,NULL,NULL,0,'c49c432a52eb94ac','AAAALU-xlnc:APA91bEfWBT2XKripmajENr7HvUVSjG_N0cYsZLxl_R3LWlDBwJyeMOlIsGz56xfiNepk1HyD71-TesOeqMj0rOpxMd5yYzekJUsPWvQYm5wOwbjEr37uCiKgfq8-hfG74HnYOA_uagg','1','0',NULL,NULL,'2020-07-23'),(15,'sachin','kumar','profile_15_5f1afe187c54a.jpg','sachinkumar8468@gmail.com','25d55ad283aa400af464c76d713c07ad','sachinkumar8468@gmail.com',NULL,'9250928150',NULL,NULL,NULL,0,0,0,NULL,NULL,0,'c49c432a52eb94ac','AAAALU-xlnc:APA91bEfWBT2XKripmajENr7HvUVSjG_N0cYsZLxl_R3LWlDBwJyeMOlIsGz56xfiNepk1HyD71-TesOeqMj0rOpxMd5yYzekJUsPWvQYm5wOwbjEr37uCiKgfq8-hfG74HnYOA_uagg','1','0',NULL,NULL,'2020-07-24');
/*!40000 ALTER TABLE `user_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_wallet`
--

DROP TABLE IF EXISTS `user_wallet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_wallet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` varchar(50) NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_wallet`
--

LOCK TABLES `user_wallet` WRITE;
/*!40000 ALTER TABLE `user_wallet` DISABLE KEYS */;
INSERT INTO `user_wallet` (`id`, `user_id`, `amount`, `updated_date`) VALUES (1,1,'0','2020-07-22 07:28:25'),(2,2,'0','2020-07-22 07:29:03'),(3,3,'0','0000-00-00 00:00:00'),(4,4,'0','2020-07-22 07:29:03'),(5,5,'0','2020-07-22 07:29:03'),(6,6,'0','2020-07-22 07:29:03'),(7,7,'160','2020-07-22 07:29:03'),(8,8,'560','2020-07-22 07:29:03'),(9,9,'0','2020-07-22 07:29:03'),(10,10,'0','2020-07-22 07:29:03'),(11,11,'0','2020-07-22 07:29:03'),(12,12,'0','2020-07-22 07:29:03'),(13,13,'0','0000-00-00 00:00:00'),(14,14,'210','0000-00-00 00:00:00'),(15,15,'20','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `user_wallet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_wallet_payment_transaction`
--

DROP TABLE IF EXISTS `user_wallet_payment_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_wallet_payment_transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `pair_id` int(11) NOT NULL,
  `withdrawal_request_id` int(11) NOT NULL,
  `amount` varchar(50) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `transaction_type` varchar(50) NOT NULL,
  `transaction_status` varchar(100) NOT NULL,
  `remark` varchar(150) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_wallet_payment_transaction`
--

LOCK TABLES `user_wallet_payment_transaction` WRITE;
/*!40000 ALTER TABLE `user_wallet_payment_transaction` DISABLE KEYS */;
INSERT INTO `user_wallet_payment_transaction` (`id`, `user_id`, `pair_id`, `withdrawal_request_id`, `amount`, `transaction_id`, `transaction_type`, `transaction_status`, `remark`, `created_date`) VALUES (1,8,0,0,'100','transaction_id','credit','success','','2020-07-21 20:32:23'),(2,8,0,0,'10','transaction_id','debit','success','','2020-07-21 20:33:06'),(3,8,0,0,'200','transaction_id','debit','success','','2020-07-21 21:02:30'),(4,8,0,0,'500','transaction_id','credit','success','','2020-07-21 21:04:41'),(5,8,0,0,'10','TID1595504792205','credit','success','','2020-07-23 06:16:54'),(6,8,0,0,'10','TID1595504898162','credit','success','','2020-07-23 06:18:35'),(7,8,0,0,'10','TID1595505085704','credit','success','','2020-07-23 06:21:41'),(8,14,0,0,'50','PTMb95135722f054c7c9f396e5190fbcd32','credit','success','','2020-07-23 13:13:57'),(9,8,1,0,'100','','credit','success','winning amount','2020-07-23 14:42:12'),(10,7,1,0,'100','','credit','success','winning amount','2020-07-23 14:43:57'),(11,7,2,0,'100','','credit','success','winning amount','2020-07-23 14:44:26'),(12,15,0,0,'20','PTM02d551979c5d4aae961255acb592585c','credit','success','','2020-07-24 07:52:48'),(13,8,12,0,'20','','credit','success','winning amount','2020-07-24 10:48:08'),(14,8,0,4,'20','','debit','Pending','','2020-07-24 10:59:01'),(15,8,0,5,'20','','debit','Pending','','2020-07-24 11:00:33'),(16,8,0,6,'20','','debit','Pending','','2020-07-24 11:01:25'),(17,8,12,0,'20','','credit','success','winning amount','2020-07-24 11:14:24'),(18,7,12,0,'20','','credit','success','winning amount','2020-07-24 11:16:29'),(19,7,12,0,'20','','credit','success','winning amount','2020-07-24 11:18:39'),(20,14,7,0,'100','','credit','success','winning amount','2020-07-24 11:52:28'),(21,14,0,0,'50','1413','debit','success','','2020-07-24 11:53:30'),(22,8,0,0,'50','813','debit','success','','2020-07-24 11:53:48'),(23,14,13,0,'100','','credit','success','winning amount','2020-07-24 11:54:47'),(24,14,0,7,'10','','debit','Pending','','2020-07-24 11:55:10'),(25,14,0,0,'10','1414','debit','success','','2020-07-24 11:56:03'),(26,8,0,0,'10','814','debit','success','','2020-07-24 11:56:03'),(27,8,14,0,'100','','credit','success','winning amount','2020-07-24 11:56:37'),(28,14,10,0,'40','','credit','success','winning amount','2020-07-24 12:18:23'),(29,15,0,0,'10','1515','debit','success','','2020-07-24 12:19:39'),(30,14,0,0,'10','1415','debit','success','','2020-07-24 12:19:39'),(31,15,15,0,'20','','credit','success','winning amount','2020-07-24 12:20:26'),(32,15,0,8,'10','','debit','Pending','','2020-07-24 12:24:32'),(33,8,0,0,'50','816','debit','success','','2020-07-24 12:25:21'),(34,8,0,0,'50','816','debit','success','','2020-07-24 13:26:52');
/*!40000 ALTER TABLE `user_wallet_payment_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fb_id` varchar(150) NOT NULL,
  `username` varchar(25) DEFAULT NULL,
  `verified` int(11) NOT NULL DEFAULT '0',
  `first_name` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(150) NOT NULL,
  `bio` varchar(150) NOT NULL,
  `profile_pic` varchar(250) NOT NULL,
  `block` varchar(100) NOT NULL DEFAULT '0',
  `version` varchar(15) DEFAULT '0',
  `device` varchar(25) NOT NULL,
  `signup_type` varchar(110) NOT NULL,
  `tokon` varchar(500) NOT NULL,
  `bearer_token` varchar(500) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `fb_id` (`fb_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_request`
--

DROP TABLE IF EXISTS `verification_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `verification_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fb_id` varchar(150) NOT NULL,
  `attachment` longtext NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_request`
--

LOCK TABLES `verification_request` WRITE;
/*!40000 ALTER TABLE `verification_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `verification_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_comment`
--

DROP TABLE IF EXISTS `video_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_id` varchar(50) NOT NULL,
  `fb_id` varchar(50) NOT NULL,
  `comments` varchar(250) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_comment`
--

LOCK TABLES `video_comment` WRITE;
/*!40000 ALTER TABLE `video_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_like_dislike`
--

DROP TABLE IF EXISTS `video_like_dislike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_like_dislike` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_id` varchar(50) NOT NULL,
  `fb_id` varchar(50) NOT NULL,
  `action` int(11) NOT NULL COMMENT '1= like ',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_like_dislike`
--

LOCK TABLES `video_like_dislike` WRITE;
/*!40000 ALTER TABLE `video_like_dislike` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_like_dislike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fb_id` varchar(50) NOT NULL,
  `description` varchar(320) NOT NULL,
  `video` varchar(500) NOT NULL DEFAULT 'NULL',
  `thum` varchar(500) NOT NULL DEFAULT 'NULL',
  `gif` varchar(500) NOT NULL DEFAULT 'NULL',
  `view` int(11) NOT NULL DEFAULT '0',
  `section` varchar(250) NOT NULL DEFAULT '0',
  `sound_id` int(11) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videos`
--

LOCK TABLES `videos` WRITE;
/*!40000 ALTER TABLE `videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wallet_withdrawal_request`
--

DROP TABLE IF EXISTS `wallet_withdrawal_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wallet_withdrawal_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `upi_id` varchar(100) NOT NULL,
  `amount` varchar(50) NOT NULL,
  `platform` varchar(100) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `release_status` enum('0','1') NOT NULL COMMENT '0:Not Release,1:Release',
  `request_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `release_date` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallet_withdrawal_request`
--

LOCK TABLES `wallet_withdrawal_request` WRITE;
/*!40000 ALTER TABLE `wallet_withdrawal_request` DISABLE KEYS */;
INSERT INTO `wallet_withdrawal_request` (`id`, `user_id`, `upi_id`, `amount`, `platform`, `mobile_no`, `release_status`, `request_date`, `release_date`) VALUES (1,5,'12345','100','paytm','123456789','0','2020-07-21 20:15:06','0000-00-00 00:00:00'),(2,8,'8749941427@ybl','10','upi','8749941427','0','2020-07-23 06:22:12','0000-00-00 00:00:00'),(3,15,'9250928150@upi','10','upi','9250928150','0','2020-07-24 07:53:31','0000-00-00 00:00:00'),(4,8,'8749941427@ybl','20','upi','8749941427','0','2020-07-24 10:59:01','0000-00-00 00:00:00'),(5,8,'8749941427@ybl','20','upi','8749941427','0','2020-07-24 11:00:33','0000-00-00 00:00:00'),(6,8,'8749941427@ybl','20','upi','8749941427','0','2020-07-24 11:01:25','0000-00-00 00:00:00'),(7,14,'9250928150@upi','10','upi','7678503464','0','2020-07-24 11:55:10','0000-00-00 00:00:00'),(8,15,'9538616955@icici','10','upi','9250928150','0','2020-07-24 12:24:32','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `wallet_withdrawal_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'shopom_gammer_pro'
--

--
-- Dumping routines for database 'shopom_gammer_pro'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-25 12:19:10
